import { create } from "zustand";
import { persist } from "zustand/middleware";

export type Profile = {
  name: string;
  email: string;
  phone: string;
};

export type Booking = {
  id: string;
  reference: string;
  name: string;
  email: string;
  phone: string;
  experienceId: string;
  experienceName: string;
  date: string;
  guests: number;
  base: number;
  vat: number;
  total: number;
  createdAt: string;
};

type Draft = Omit<Booking, "id" | "reference" | "createdAt">;

type AdventureState = {
  hydrated: boolean;
  profile: Profile | null;
  bookings: Booking[];
  saved: string[];
  setProfile: (profile: Profile) => void;
  signOut: () => void;
  toggleSaved: (id: string) => void;
  addBooking: (draft: Draft) => Booking;
};

export const useAdventure = create<AdventureState>()(
  persist(
    (set, get) => ({
      hydrated: false,
      profile: null,
      bookings: [],
      saved: [],
      setProfile: (profile) => set({ profile }),
      signOut: () => set({ profile: null }),
      toggleSaved: (id) => {
        const saved = get().saved;
        set({
          saved: saved.includes(id) ? saved.filter((item) => item !== id) : [...saved, id],
        });
      },
      addBooking: (draft) => {
        const reference = `AES-2026-${String(get().bookings.length + 1).padStart(3, "0")}`;
        const booking: Booking = {
          ...draft,
          id: crypto.randomUUID(),
          reference,
          createdAt: new Date().toISOString(),
        };
        set({ bookings: [booking, ...get().bookings] });
        return booking;
      },
    }),
    {
      name: "adventure-escape-sa",
      partialize: (state) => ({
        profile: state.profile,
        bookings: state.bookings,
        saved: state.saved,
      }),
    },
  ),
);
