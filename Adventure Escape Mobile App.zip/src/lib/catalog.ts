export type ExperienceKind = "package" | "activity";

export type Experience = {
  id: string;
  kind: ExperienceKind;
  name: string;
  shortName: string;
  tagline: string;
  price: number;
  perPerson: boolean;
  image: string;
  imageAlt: string;
  badge: string;
  overview: string[];
};

export const VAT_RATE = 0.15;
export const MULTI_DISCOUNT = 0.05;

export const experiences: Experience[] = [
  {
    id: "ultimate",
    kind: "package",
    name: "Ultimate Adventure Day",
    shortName: "Ultimate Day",
    tagline: "A full day of outdoor thrills",
    price: 1500,
    perPerson: false,
    image: "/photos/ridge.jpg",
    imageAlt: "Sunrise on a Western Cape mountain ridge above the coast",
    badge: "Ultimate day",
    overview: [
      "Guided zipline and trail combo",
      "Coastal lookout stop",
      "Local adventure guide",
      "Safety briefing and gear check",
    ],
  },
  {
    id: "family",
    kind: "package",
    name: "Family Explorer Package",
    shortName: "Family Fun",
    tagline: "Shared fun for all ages",
    price: 1500,
    perPerson: false,
    image: "/photos/family.jpg",
    imageAlt: "A fynbos hiking trail in the Western Cape",
    badge: "Family fun",
    overview: [
      "Gentle trails suited to families",
      "Scenic stops and photo moments",
      "A guide who keeps an easy pace",
      "Gear guidance for every age",
    ],
  },
  {
    id: "mountain",
    kind: "package",
    name: "Mountain Adventure Package",
    shortName: "Mountain",
    tagline: "Scenic trails and fresh air",
    price: 1500,
    perPerson: false,
    image: "/photos/cape.jpg",
    imageAlt: "Sandstone mountains and fynbos in the Western Cape",
    badge: "Mountain",
    overview: [
      "Guided mountain outing",
      "Scenic stops and photo moments",
      "Helpful local adventure guide",
      "Suitable gear guidance included",
    ],
  },
  {
    id: "corporate",
    kind: "package",
    name: "Corporate Team Challenge",
    shortName: "Team Challenge",
    tagline: "Build trust beyond the office",
    price: 1500,
    perPerson: false,
    image: "/photos/team.jpg",
    imageAlt: "An outdoor team challenge course with mountains behind it",
    badge: "Team challenge",
    overview: [
      "Facilitated team challenges",
      "Shared problem-solving outdoors",
      "A dedicated group guide",
      "A short debrief before you head back",
    ],
  },
  {
    id: "zipline",
    kind: "activity",
    name: "Ziplining Adventure",
    shortName: "Ziplining",
    tagline: "Fly above the forest canopy",
    price: 750,
    perPerson: true,
    image: "/photos/zipline.jpg",
    imageAlt: "A zipline cable through indigenous forest canopy",
    badge: "Zipline",
    overview: [
      "Guided canopy zipline",
      "Harness, helmet, and briefing",
      "Suitable for first-time flyers",
      "Forest lookout at the end of the line",
    ],
  },
  {
    id: "kayak",
    kind: "activity",
    name: "Kayaking Experience",
    shortName: "Kayaking",
    tagline: "Paddle across beautiful waters",
    price: 750,
    perPerson: true,
    image: "/photos/kayak.jpg",
    imageAlt: "A sea kayak on calm water beside sandstone cliffs",
    badge: "Kayaking",
    overview: [
      "Calm-water paddle with a guide",
      "Kayak and paddle provided",
      "Time to drift and take photos",
      "Safety briefing before you launch",
    ],
  },
  {
    id: "climb",
    kind: "activity",
    name: "Rock Climbing Session",
    shortName: "Rock climbing",
    tagline: "Challenge yourself safely",
    price: 750,
    perPerson: true,
    image: "/photos/climb.jpg",
    imageAlt: "A sunlit sandstone climbing cliff with safety ropes",
    badge: "Rock climbing",
    overview: [
      "Introductory climbs on solid rock",
      "Harness and helmet included",
      "A guide on the rope the whole time",
      "Pace set for your group",
    ],
  },
];

export const packages = experiences.filter((item) => item.kind === "package");
export const activities = experiences.filter((item) => item.kind === "activity");

export function findExperience(id: string | undefined) {
  if (!id) return undefined;
  return experiences.find((item) => item.id === id);
}

export function formatRand(amount: number, decimals = 0) {
  const formatted = amount.toLocaleString("en-US", {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
  return `R${formatted}`;
}

export function quoteSelected(ids: string[]) {
  const items = ids
    .map((id) => findExperience(id))
    .filter((item): item is Experience => Boolean(item));
  const subtotal = items.reduce((sum, item) => sum + item.price, 0);
  const discount = items.length >= 2 ? roundMoney(subtotal * MULTI_DISCOUNT) : 0;
  const afterDiscount = roundMoney(subtotal - discount);
  const vat = roundMoney(afterDiscount * VAT_RATE);
  const total = roundMoney(afterDiscount + vat);
  return { items, subtotal, discount, vat, total };
}

export function bookingQuote(experience: Experience, guests: number) {
  const safeGuests = Math.max(1, guests);
  const base = experience.perPerson ? roundMoney(experience.price * safeGuests) : experience.price;
  const vat = roundMoney(base * VAT_RATE);
  const total = roundMoney(base + vat);
  return { base, vat, total, guests: safeGuests };
}

function roundMoney(value: number) {
  return Math.round(value * 100) / 100;
}

export function initialsFrom(name: string) {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return "AE";
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return `${parts[0][0]}${parts[parts.length - 1][0]}`.toUpperCase();
}

export function prettyDate(iso: string) {
  const [year, month, day] = iso.split("-").map(Number);
  if (!year || !month || !day) return iso;
  return new Date(year, month - 1, day).toLocaleDateString("en-GB", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });
}

export function todayISO() {
  const now = new Date();
  const month = String(now.getMonth() + 1).padStart(2, "0");
  const day = String(now.getDate()).padStart(2, "0");
  return `${now.getFullYear()}-${month}-${day}`;
}
