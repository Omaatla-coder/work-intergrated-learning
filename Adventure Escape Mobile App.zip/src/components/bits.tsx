import type { ButtonHTMLAttributes, ReactNode } from "react";
import { Heart } from "lucide-react";
import { useAdventure } from "@/lib/adventure-store";

const primaryClass =
  "inline-flex h-12 w-full items-center justify-center rounded-control bg-ember px-4 text-sm font-semibold text-snow transition hover:bg-ember-deep active:scale-95 disabled:cursor-not-allowed disabled:opacity-50";

const inkClass =
  "inline-flex h-12 w-full items-center justify-center rounded-control bg-ink px-4 text-sm font-semibold text-snow transition hover:bg-ink-soft active:scale-95";

export function PrimaryButton(props: ButtonHTMLAttributes<HTMLButtonElement>) {
  return <button {...props} className={`${primaryClass} ${props.className ?? ""}`} />;
}

export function InkButton(props: ButtonHTMLAttributes<HTMLButtonElement>) {
  return <button {...props} className={`${inkClass} ${props.className ?? ""}`} />;
}

export function FieldLabel({ htmlFor, children }: { htmlFor: string; children: ReactNode }) {
  return (
    <label htmlFor={htmlFor} className="mb-1.5 block text-xs font-bold text-ink">
      {children}
    </label>
  );
}

export function FieldError({ children }: { children?: string }) {
  if (!children) return null;
  return <p className="mt-1.5 text-xs font-semibold text-ember">{children}</p>;
}

export function SaveButton({ id }: { id: string }) {
  const hydrated = useAdventure((state) => state.hydrated);
  const saved = useAdventure((state) => state.saved.includes(id));
  const toggleSaved = useAdventure((state) => state.toggleSaved);
  const on = hydrated && saved;

  return (
    <button
      type="button"
      aria-pressed={on}
      aria-label={on ? "Remove from saved adventures" : "Save this adventure"}
      onClick={() => toggleSaved(id)}
      className="grid size-11 place-items-center rounded-full bg-card text-forest shadow-sm"
    >
      <Heart className={`size-5 ${on ? "fill-forest" : ""}`} aria-hidden="true" />
    </button>
  );
}
