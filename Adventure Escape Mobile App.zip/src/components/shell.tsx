import { useEffect, type ReactNode } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { Home, LayoutGrid, Mail, Mountain, Receipt } from "lucide-react";
import { initialsFrom } from "@/lib/catalog";
import { useAdventure } from "@/lib/adventure-store";

const tabs = [
  { to: "/home", label: "Home", icon: Home },
  { to: "/packages", label: "Packages", icon: LayoutGrid },
  { to: "/activities", label: "Activities", icon: Mountain },
  { to: "/fees", label: "Fees", icon: Receipt },
  { to: "/contact", label: "Contact", icon: Mail },
] as const;

export function Stage({ children }: { children: ReactNode }) {
  useEffect(() => {
    const finish = () => useAdventure.setState({ hydrated: true });
    if (useAdventure.persist.hasHydrated()) finish();
    return useAdventure.persist.onFinishHydration(finish);
  }, []);

  return (
    <div className="flex h-dvh w-full overflow-hidden bg-stage text-ink">
      <aside className="hidden min-w-0 flex-1 flex-col justify-end px-10 py-14 lg:flex">
        <p className="text-xs font-semibold tracking-widest text-sun">WESTERN CAPE</p>
        <p className="mt-3 max-w-xs font-display text-4xl font-semibold leading-tight text-snow">
          Adventure Escape SA
        </p>
        <p className="mt-4 max-w-xs text-sm leading-relaxed text-on-ink">
          Guided days outside, from peninsula trails to quiet water. Founded in 2024 by Liam Daniels.
        </p>
      </aside>
      <div className="flex h-dvh w-full max-w-md shrink-0 flex-col bg-paper">{children}</div>
      <aside className="hidden min-w-0 flex-1 items-center justify-start px-8 lg:flex">
        <figure className="w-full max-w-sm">
          <img
            src="/photos/aerial.jpg"
            alt="Aerial view of the Cape Peninsula coastline"
            className="h-80 w-full rounded-card object-cover"
          />
          <figcaption className="mt-3 text-xs font-semibold tracking-widest text-sun">
            CAPE PENINSULA
          </figcaption>
        </figure>
      </aside>
    </div>
  );
}

export function AppHeader() {
  const hydrated = useAdventure((state) => state.hydrated);
  const profile = useAdventure((state) => state.profile);
  const initials = hydrated && profile ? initialsFrom(profile.name) : "AE";

  return (
    <header className="flex shrink-0 items-center justify-between bg-ink px-5 py-3.5 text-on-ink">
      <Link to="/home" className="block rounded-md">
        <p className="text-xs font-semibold tracking-widest text-sun">ADVENTURE</p>
        <p className="font-display text-xl font-bold leading-none text-snow">Escape SA</p>
      </Link>
      <Link
        to="/profile"
        aria-label="Your adventure profile"
        className="grid size-11 place-items-center rounded-full bg-forest text-xs font-bold text-snow"
      >
        {initials}
      </Link>
    </header>
  );
}

export function BottomNav() {
  const pathname = useRouterState({ select: (state) => state.location.pathname });

  return (
    <nav className="nav-pad shrink-0 border-t border-line bg-card">
      <ul className="grid grid-cols-5">
        {tabs.map((tab) => {
          const active = pathname === tab.to;
          const Icon = tab.icon;
          return (
            <li key={tab.to}>
              <Link
                to={tab.to}
                className={`flex min-h-14 flex-col items-center justify-center gap-1 text-xs font-semibold ${
                  active ? "text-ember" : "text-muted"
                }`}
              >
                <Icon className="size-5" strokeWidth={2.2} aria-hidden="true" />
                {tab.label}
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  return (
    <Stage>
      <AppHeader />
      <main className="device-scroll min-h-0 flex-1 overflow-y-auto px-5 py-5">{children}</main>
      <BottomNav />
    </Stage>
  );
}
