import { createFileRoute, Link } from "@tanstack/react-router";
import { AppShell } from "@/components/shell";
import { activities, formatRand } from "@/lib/catalog";

export const Route = createFileRoute("/home")({ component: HomePage });

function HomePage() {
  return (
    <AppShell>
      <section className="relative overflow-hidden rounded-card bg-mist">
        <img
          src="/photos/cape.jpg"
          alt="Western Cape mountains in late light"
          className="h-48 w-full object-cover"
        />
        <p className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-ink/80 to-transparent px-3 py-3 text-center text-xs font-bold tracking-widest text-snow">
          ADVENTURE STARTS HERE
        </p>
      </section>

      <h1 className="mt-6 font-display text-3xl font-bold leading-tight text-ink">
        Discover Your Next
        <br />
        Adventure
      </h1>
      <p className="mt-2 text-sm text-muted">Explore the beauty of the Western Cape.</p>
      <p className="mt-3 flex gap-4 text-sm font-semibold text-forest">
        <Link to="/about" className="underline decoration-forest/40 underline-offset-4">
          Our story
        </Link>
        <Link to="/location" className="underline decoration-forest/40 underline-offset-4">
          Find us
        </Link>
      </p>

      <Link
        to="/packages"
        className="mt-5 inline-flex h-12 w-full items-center justify-center rounded-control bg-ember text-sm font-semibold text-snow transition hover:bg-ember-deep active:scale-95"
      >
        Explore Packages
      </Link>

      <h2 className="mt-8 font-display text-xl font-bold text-ink">Popular experiences</h2>
      <ul className="mt-3 grid grid-cols-3 gap-2.5">
        {activities.map((activity) => (
          <li key={activity.id}>
            <Link
              to="/book"
              search={{ experience: activity.id }}
              className="block rounded-card border border-line bg-card p-1.5"
            >
              <img
                src={activity.image}
                alt=""
                className="h-16 w-full rounded-lg object-cover"
              />
              <p className="mt-2 truncate px-0.5 text-xs font-bold text-ink">{activity.shortName}</p>
              <p className="px-0.5 pb-1 text-sm font-extrabold text-forest tabular-nums">
                {formatRand(activity.price)}
              </p>
            </Link>
          </li>
        ))}
      </ul>
    </AppShell>
  );
}
