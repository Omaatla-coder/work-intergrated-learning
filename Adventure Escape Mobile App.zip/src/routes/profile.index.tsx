import { useState, type FormEvent } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ChevronRight } from "lucide-react";
import { AppShell } from "@/components/shell";
import { FieldError, FieldLabel, InkButton } from "@/components/bits";
import { initialsFrom } from "@/lib/catalog";
import { useAdventure } from "@/lib/adventure-store";

export const Route = createFileRoute("/profile/")({ component: ProfilePage });

const rows = [
  { to: "/profile/details", title: "Personal details", note: "Manage your contact information" },
  { to: "/profile/bookings", title: "My bookings", note: "View upcoming experiences" },
  { to: "/profile/saved", title: "Saved adventures", note: "Keep favourites in one place" },
  { to: "/profile/help", title: "Help & support", note: "Get assistance from our team" },
] as const;

const inputClass =
  "h-12 w-full rounded-control border border-line bg-card px-3.5 text-base text-ink outline-none placeholder:text-faint focus:border-forest focus:ring-2 focus:ring-forest/25";

function ProfilePage() {
  const hydrated = useAdventure((state) => state.hydrated);
  const profile = useAdventure((state) => state.profile);
  const setProfile = useAdventure((state) => state.setProfile);
  const signOut = useAdventure((state) => state.signOut);
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [error, setError] = useState("");

  const signedIn = hydrated && profile;
  const first = signedIn ? profile.name.trim().split(/\s+/)[0] : "";

  function save(event: FormEvent) {
    event.preventDefault();
    if (name.trim().length < 2) {
      setError("Enter the name you want on your bookings.");
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      setError("Enter a valid email address.");
      return;
    }
    setProfile({ name: name.trim(), email: email.trim(), phone: phone.trim() });
    setOpen(false);
    setError("");
  }

  return (
    <AppShell>
      <h1 className="font-display text-3xl font-bold text-ink">Your adventure profile</h1>
      <div className="mt-5 flex items-center gap-4">
        <div className="grid size-16 place-items-center rounded-full bg-mist text-lg font-extrabold text-forest">
          {signedIn ? initialsFrom(profile.name) : "AE"}
        </div>
        <div>
          <p className="font-display text-lg font-bold text-ink">
            {signedIn ? `Welcome, ${first}` : "Welcome, explorer"}
          </p>
          <p className="text-sm text-muted">
            {signedIn ? profile.email : "Sign in to manage your plans"}
          </p>
        </div>
      </div>

      <ul className="mt-6 space-y-3">
        {rows.map((row) => (
          <li key={row.to}>
            <Link
              to={row.to}
              className="flex min-h-16 items-center justify-between rounded-card border border-line bg-card px-4 py-3"
            >
              <span>
                <span className="block text-sm font-extrabold text-ink">{row.title}</span>
                <span className="mt-0.5 block text-xs text-muted">{row.note}</span>
              </span>
              <ChevronRight className="size-5 text-forest" aria-hidden="true" />
            </Link>
          </li>
        ))}
      </ul>

      {signedIn ? (
        <button
          type="button"
          onClick={signOut}
          className="mt-6 h-12 w-full rounded-control border border-line bg-card text-sm font-semibold text-ink"
        >
          Sign out
        </button>
      ) : open ? (
        <form className="mt-6 space-y-3 rounded-card border border-line bg-card p-4" onSubmit={save}>
          <p className="text-sm font-bold text-ink">Create your profile</p>
          <p className="text-xs text-muted">Saved on this device so booking forms can use it.</p>
          <div>
            <FieldLabel htmlFor="profile-name">Full name</FieldLabel>
            <input id="profile-name" className={inputClass} value={name} onChange={(event) => setName(event.target.value)} />
          </div>
          <div>
            <FieldLabel htmlFor="profile-email">Email</FieldLabel>
            <input
              id="profile-email"
              type="email"
              className={inputClass}
              value={email}
              onChange={(event) => setEmail(event.target.value)}
            />
          </div>
          <div>
            <FieldLabel htmlFor="profile-phone">Phone</FieldLabel>
            <input
              id="profile-phone"
              type="tel"
              className={inputClass}
              placeholder="+27"
              value={phone}
              onChange={(event) => setPhone(event.target.value)}
            />
          </div>
          <FieldError>{error}</FieldError>
          <InkButton type="submit">Save profile</InkButton>
        </form>
      ) : (
        <InkButton className="mt-6" type="button" onClick={() => setOpen(true)}>
          Sign in / Create account
        </InkButton>
      )}
    </AppShell>
  );
}
