import { createFileRoute, Link } from "@tanstack/react-router";
import { AppShell } from "@/components/shell";
import { formatRand, prettyDate } from "@/lib/catalog";
import { useAdventure } from "@/lib/adventure-store";

export const Route = createFileRoute("/profile/bookings")({ component: BookingsPage });

function BookingsPage() {
  const hydrated = useAdventure((state) => state.hydrated);
  const bookings = useAdventure((state) => state.bookings);

  return (
    <AppShell>
      <Link to="/profile" className="text-sm font-semibold text-forest">
        Back to profile
      </Link>
      <h1 className="mt-3 font-display text-3xl font-bold text-ink">My bookings</h1>
      <p className="mt-1 text-sm text-muted">Requests saved on this device.</p>

      {!hydrated ? null : bookings.length === 0 ? (
        <div className="mt-6 rounded-card border border-line bg-card p-5">
          <p className="text-sm text-muted">No adventures booked yet.</p>
          <Link to="/packages" className="mt-3 inline-flex text-sm font-semibold text-forest">
            Browse packages
          </Link>
        </div>
      ) : (
        <ul className="mt-5 space-y-3">
          {bookings.map((booking) => (
            <li key={booking.id} className="rounded-card border border-line bg-card p-4">
              <p className="text-xs font-bold tracking-widest text-muted">{booking.reference}</p>
              <h2 className="mt-1 font-display text-lg font-bold text-ink">{booking.experienceName}</h2>
              <p className="mt-1 text-sm text-muted">
                {prettyDate(booking.date)} · {booking.guests} {booking.guests === 1 ? "guest" : "guests"}
              </p>
              <p className="mt-2 text-sm font-extrabold text-forest tabular-nums">
                {formatRand(booking.total, 2)}
              </p>
            </li>
          ))}
        </ul>
      )}
    </AppShell>
  );
}
