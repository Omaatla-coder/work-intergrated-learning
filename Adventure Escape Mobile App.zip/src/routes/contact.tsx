import { useState, type FormEvent } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { AppShell } from "@/components/shell";
import { FieldError, FieldLabel, PrimaryButton } from "@/components/bits";

export const Route = createFileRoute("/contact")({ component: ContactPage });

const inputClass =
  "w-full rounded-control border border-line bg-card px-3.5 text-base text-ink outline-none transition placeholder:text-faint focus:border-forest focus:ring-2 focus:ring-forest/25";

function ContactPage() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const [errors, setErrors] = useState<{ name?: string; email?: string; message?: string }>({});
  const [sent, setSent] = useState(false);

  function submit(event: FormEvent) {
    event.preventDefault();
    const next: typeof errors = {};
    if (name.trim().length < 2) next.name = "Enter your name.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) next.email = "Enter a valid email address.";
    if (message.trim().length < 8) next.message = "Tell us a little more so we can help.";
    setErrors(next);
    if (Object.keys(next).length === 0) setSent(true);
  }

  return (
    <AppShell>
      <h1 className="font-display text-3xl font-bold text-ink">Contact our team</h1>
      <p className="mt-1 text-sm text-muted">We are happy to help plan your escape.</p>

      {sent ? (
        <section className="mt-6 rounded-card border border-line bg-card p-5">
          <p className="font-display text-2xl font-bold text-ink">Message received</p>
          <p className="mt-2 text-sm leading-relaxed text-muted">
            Thanks, {name.trim().split(" ")[0]}. We will reply to {email.trim()} as soon as we can.
          </p>
          <button
            type="button"
            className="mt-4 text-sm font-semibold text-forest"
            onClick={() => {
              setSent(false);
              setMessage("");
            }}
          >
            Send another message
          </button>
        </section>
      ) : (
        <form className="mt-5 space-y-4" onSubmit={submit} noValidate>
          <div>
            <FieldLabel htmlFor="contact-name">Name</FieldLabel>
            <input
              id="contact-name"
              className={`${inputClass} h-12`}
              placeholder="Your full name"
              autoComplete="name"
              value={name}
              onChange={(event) => setName(event.target.value)}
            />
            <FieldError>{errors.name}</FieldError>
          </div>
          <div>
            <FieldLabel htmlFor="contact-email">Email</FieldLabel>
            <input
              id="contact-email"
              type="email"
              className={`${inputClass} h-12`}
              placeholder="you@example.com"
              autoComplete="email"
              value={email}
              onChange={(event) => setEmail(event.target.value)}
            />
            <FieldError>{errors.email}</FieldError>
          </div>
          <div>
            <FieldLabel htmlFor="contact-message">Message</FieldLabel>
            <textarea
              id="contact-message"
              className={`${inputClass} min-h-24 py-3`}
              placeholder="How can we help?"
              value={message}
              onChange={(event) => setMessage(event.target.value)}
            />
            <FieldError>{errors.message}</FieldError>
          </div>
          <PrimaryButton type="submit">Send message</PrimaryButton>
        </form>
      )}

      <div className="mt-8">
        <p className="text-xs font-extrabold text-forest">Email</p>
        <a className="mt-1 block text-sm text-ink" href="mailto:hello@adventureescapesa.co.za">
          hello@adventureescapesa.co.za
        </a>
        <Link to="/location" className="mt-4 block text-sm text-muted underline decoration-line underline-offset-4">
          Based in the Western Cape, South Africa
        </Link>
      </div>
    </AppShell>
  );
}
