import { createFileRoute, Link } from "@tanstack/react-router";
import { Stage } from "@/components/shell";

export const Route = createFileRoute("/")({ component: Splash });

function Splash() {
  return (
    <Stage>
      <main className="relative flex h-full min-h-0 flex-1 flex-col overflow-hidden bg-ink text-on-ink">
        <img
          src="/photos/cape.jpg"
          alt=""
          className="absolute inset-0 h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-ink/25 via-ink/15 to-ink/80" />
        <div className="relative z-10 flex flex-1 flex-col items-center justify-center px-8 text-center">
          <p className="text-sm font-semibold tracking-widest text-sun">ADVENTURE</p>
          <h1 className="mt-2 font-display text-4xl font-bold uppercase leading-none text-snow">
            Escape SA
          </h1>
          <p className="mt-4 text-base text-on-ink">Find your next wild moment.</p>
        </div>
        <div className="relative z-10 px-8 pb-12">
          <Link
            to="/home"
            className="inline-flex h-12 w-full items-center justify-center rounded-control bg-ember text-sm font-bold tracking-wide text-snow transition hover:bg-ember-deep active:scale-95"
          >
            START EXPLORING
          </Link>
          <p className="mt-5 text-center text-xs font-bold tracking-widest text-snow">
            EXPLORE THE WESTERN CAPE
          </p>
        </div>
      </main>
    </Stage>
  );
}
