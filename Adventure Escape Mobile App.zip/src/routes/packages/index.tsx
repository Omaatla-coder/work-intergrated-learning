import { createFileRoute, Link } from "@tanstack/react-router";
import { AppShell } from "@/components/shell";
import { SaveButton } from "@/components/bits";
import { formatRand, packages } from "@/lib/catalog";

export const Route = createFileRoute("/packages/")({ component: PackagesPage });

function PackagesPage() {
  return (
    <AppShell>
      <h1 className="font-display text-3xl font-bold text-ink">Choose your adventure</h1>
      <p className="mt-1 text-sm text-muted">Simple packages. Big memories.</p>
      <ul className="mt-5 space-y-3">
        {packages.map((item) => (
          <li key={item.id} className="flex gap-3 rounded-card border border-line bg-card p-2">
            <div className="relative h-28 w-28 shrink-0">
              <img
                src={item.image}
                alt=""
                className="h-full w-full rounded-card object-cover"
              />
              <p className="absolute inset-x-0 bottom-0 rounded-b-card bg-ink/70 px-1 py-1 text-center text-xs font-bold tracking-wide text-snow">
                {item.badge.toUpperCase()}
              </p>
            </div>
            <div className="flex min-w-0 flex-1 flex-col py-1 pr-1">
              <div className="flex items-start justify-between gap-2">
                <h2 className="font-display text-base font-bold leading-tight text-ink">{item.name}</h2>
                <SaveButton id={item.id} />
              </div>
              <p className="mt-1 text-xs text-muted">{item.tagline}</p>
              <p className="mt-auto pt-2 text-lg font-extrabold text-forest tabular-nums">
                {formatRand(item.price)}
              </p>
              <Link
                to="/packages/$id"
                params={{ id: item.id }}
                className="mt-2 inline-flex h-11 items-center justify-center rounded-control bg-ember text-sm font-semibold text-snow"
              >
                View details
              </Link>
            </div>
          </li>
        ))}
      </ul>
    </AppShell>
  );
}
