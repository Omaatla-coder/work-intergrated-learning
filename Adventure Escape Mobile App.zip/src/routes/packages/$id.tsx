import { createFileRoute, Link } from "@tanstack/react-router";
import { AppShell } from "@/components/shell";
import { SaveButton } from "@/components/bits";
import { findExperience, formatRand } from "@/lib/catalog";

export const Route = createFileRoute("/packages/$id")({ component: PackageDetail });

function PackageDetail() {
  const { id } = Route.useParams();
  const item = findExperience(id);

  if (!item || item.kind !== "package") {
    return (
      <AppShell>
        <h1 className="font-display text-3xl font-bold text-ink">Package not found</h1>
        <p className="mt-2 text-sm text-muted">That adventure is not on the list.</p>
        <Link to="/packages" className="mt-6 inline-flex font-semibold text-forest">
          Back to packages
        </Link>
      </AppShell>
    );
  }

  return (
    <AppShell>
      <section className="relative overflow-hidden rounded-card bg-mist">
        <img src={item.image} alt={item.imageAlt} className="h-48 w-full object-cover" />
        <p className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-ink/80 to-transparent px-3 py-3 text-center text-xs font-bold tracking-widest text-snow">
          {item.badge.toUpperCase()}
        </p>
        <div className="absolute right-3 top-3">
          <SaveButton id={item.id} />
        </div>
      </section>

      <h1 className="mt-5 font-display text-3xl font-bold leading-tight text-ink">{item.name}</h1>
      <h2 className="mt-3 text-sm font-extrabold text-forest">Package overview</h2>
      <ul className="mt-3 space-y-2.5 text-sm text-muted">
        {item.overview.map((point) => (
          <li key={point} className="flex gap-2">
            <span aria-hidden="true">•</span>
            <span>{point}</span>
          </li>
        ))}
      </ul>

      <hr className="my-5 border-line" />
      <p className="text-sm text-muted">Package price</p>
      <p className="mt-1 font-display text-3xl font-bold text-ink tabular-nums">{formatRand(item.price)}</p>
      <p className="mt-1 text-xs text-muted">Priced for the group. Guest count is confirmed when you book.</p>

      <Link
        to="/book"
        search={{ experience: item.id }}
        className="mt-5 inline-flex h-12 w-full items-center justify-center rounded-control bg-ember text-sm font-semibold text-snow transition hover:bg-ember-deep active:scale-95"
      >
        Continue to booking
      </Link>
    </AppShell>
  );
}
