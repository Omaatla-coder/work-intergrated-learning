import { createFileRoute, Link } from "@tanstack/react-router";
import { ShieldCheck, Users, Compass } from "lucide-react";
import { AppShell } from "@/components/shell";

export const Route = createFileRoute("/about")({ component: AboutPage });

const reasons = [
  { icon: Compass, text: "Friendly local guides" },
  { icon: Users, text: "Experiences for every group" },
  { icon: ShieldCheck, text: "Safety-first planning" },
];

function AboutPage() {
  return (
    <AppShell>
      <section className="relative overflow-hidden rounded-card bg-mist">
        <img
          src="/photos/family.jpg"
          alt="A trail through Western Cape fynbos"
          className="h-40 w-full object-cover"
        />
        <p className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-ink/75 to-transparent px-3 py-3 text-center text-xs font-bold tracking-widest text-snow">
          OUR STORY
        </p>
      </section>

      <h1 className="mt-6 font-display text-3xl font-bold leading-tight text-ink">
        Adventure with purpose
      </h1>
      <h2 className="mt-4 text-lg font-extrabold text-forest">Our Story</h2>
      <p className="mt-2 text-sm leading-relaxed text-muted">
        Founded in 2024 by Liam Daniels, Adventure Escape SA creates memorable guided outdoor
        experiences across the beautiful Western Cape.
      </p>

      <h2 className="mt-6 font-display text-xl font-bold text-ink">Why choose us?</h2>
      <ul className="mt-3 space-y-3">
        {reasons.map((reason) => (
          <li key={reason.text} className="flex items-center gap-3 text-sm font-semibold text-forest">
            <reason.icon className="size-5 shrink-0" aria-hidden="true" />
            {reason.text}
          </li>
        ))}
      </ul>

      <Link
        to="/packages"
        className="mt-8 inline-flex h-12 items-center justify-center rounded-control bg-ember px-6 text-sm font-semibold text-snow transition hover:bg-ember-deep active:scale-95"
      >
        Explore our packages
      </Link>
    </AppShell>
  );
}
