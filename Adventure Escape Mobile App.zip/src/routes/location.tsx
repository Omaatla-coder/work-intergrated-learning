import { createFileRoute, Link } from "@tanstack/react-router";
import { MapPin } from "lucide-react";
import { AppShell } from "@/components/shell";

export const Route = createFileRoute("/location")({ component: LocationPage });

function LocationPage() {
  return (
    <AppShell>
      <h1 className="font-display text-3xl font-bold text-ink">Find your adventure</h1>
      <p className="mt-1 text-sm text-muted">Western Cape, South Africa</p>

      <div className="relative mt-5 overflow-hidden rounded-card border border-line bg-mist">
        <img
          src="/photos/aerial.jpg"
          alt="Aerial view of the Cape Peninsula, where adventures are based"
          className="h-72 w-full object-cover"
        />
        <div className="absolute left-1/2 top-1/2 grid -translate-x-1/2 -translate-y-1/2 place-items-center">
          <span className="grid size-12 place-items-center rounded-full border-4 border-snow bg-ember text-snow shadow-lg">
            <MapPin className="size-5" aria-hidden="true" />
          </span>
        </div>
        <p className="absolute bottom-3 left-3 rounded-full bg-ink/80 px-3 py-1 text-xs font-semibold text-snow">
          Cape Peninsula
        </p>
      </div>

      <h2 className="mt-6 font-display text-xl font-bold text-ink">Plan your route</h2>
      <p className="mt-2 text-sm leading-relaxed text-muted">
        Exact meeting points are shared after your booking is confirmed.
      </p>

      <Link
        to="/contact"
        className="mt-6 inline-flex h-12 w-full items-center justify-center rounded-control bg-ember text-sm font-semibold text-snow transition hover:bg-ember-deep active:scale-95"
      >
        Contact our team
      </Link>
    </AppShell>
  );
}
