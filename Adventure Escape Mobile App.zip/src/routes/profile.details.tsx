import { useEffect, useState, type FormEvent } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { AppShell } from "@/components/shell";
import { FieldError, FieldLabel, PrimaryButton } from "@/components/bits";
import { useAdventure } from "@/lib/adventure-store";

export const Route = createFileRoute("/profile/details")({ component: DetailsPage });

const inputClass =
  "h-12 w-full rounded-control border border-line bg-card px-3.5 text-base text-ink outline-none placeholder:text-faint focus:border-forest focus:ring-2 focus:ring-forest/25";

function DetailsPage() {
  const profile = useAdventure((state) => state.profile);
  const setProfile = useAdventure((state) => state.setProfile);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [error, setError] = useState("");
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    if (!profile) return;
    setName(profile.name);
    setEmail(profile.email);
    setPhone(profile.phone);
  }, [profile]);

  function submit(event: FormEvent) {
    event.preventDefault();
    if (name.trim().length < 2) {
      setError("Enter your full name.");
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      setError("Enter a valid email address.");
      return;
    }
    setProfile({ name: name.trim(), email: email.trim(), phone: phone.trim() });
    setError("");
    setSaved(true);
  }

  return (
    <AppShell>
      <Link to="/profile" className="text-sm font-semibold text-forest">
        Back to profile
      </Link>
      <h1 className="mt-3 font-display text-3xl font-bold text-ink">Personal details</h1>
      <p className="mt-1 text-sm text-muted">These details stay on this device and fill in new bookings.</p>
      <form className="mt-5 space-y-4" onSubmit={submit}>
        <div>
          <FieldLabel htmlFor="detail-name">Full name</FieldLabel>
          <input id="detail-name" className={inputClass} value={name} onChange={(event) => setName(event.target.value)} />
        </div>
        <div>
          <FieldLabel htmlFor="detail-email">Email</FieldLabel>
          <input
            id="detail-email"
            type="email"
            className={inputClass}
            value={email}
            onChange={(event) => setEmail(event.target.value)}
          />
        </div>
        <div>
          <FieldLabel htmlFor="detail-phone">Phone</FieldLabel>
          <input
            id="detail-phone"
            type="tel"
            className={inputClass}
            placeholder="+27"
            value={phone}
            onChange={(event) => setPhone(event.target.value)}
          />
        </div>
        <FieldError>{error}</FieldError>
        {saved ? <p className="text-sm font-semibold text-forest">Details saved.</p> : null}
        <PrimaryButton type="submit">Save details</PrimaryButton>
      </form>
    </AppShell>
  );
}
