import { createFileRoute, Link } from "@tanstack/react-router";
import { AppShell } from "@/components/shell";
import { formatRand, prettyDate } from "@/lib/catalog";
import { useAdventure } from "@/lib/adventure-store";

export const Route = createFileRoute("/confirmation")({ component: ConfirmationPage });

function ConfirmationPage() {
  const hydrated = useAdventure((state) => state.hydrated);
  const booking = useAdventure((state) => state.bookings[0]);

  return (
    <AppShell>
      <section className="rounded-card border border-line bg-card px-5 py-8 text-center">
        <div className="mx-auto grid size-20 place-items-center rounded-full bg-mist text-4xl font-bold text-forest">
          ✓
        </div>
        <h1 className="mt-4 font-display text-3xl font-bold text-ink">You’re all set!</h1>
        <p className="mt-2 text-sm text-muted">Your booking request has been received.</p>
        <hr className="my-5 border-line" />
        {hydrated && booking ? (
          <div className="text-left">
            <p className="text-xs font-bold tracking-widest text-muted">REFERENCE</p>
            <p className="mt-1 font-display text-2xl font-bold text-ink">{booking.reference}</p>
            <p className="mt-4 text-sm font-semibold text-ink">{booking.experienceName}</p>
            <p className="mt-1 text-sm text-muted">
              {prettyDate(booking.date)} · {booking.guests} {booking.guests === 1 ? "guest" : "guests"}
            </p>
            <p className="mt-1 text-sm font-bold text-forest tabular-nums">
              {formatRand(booking.total, 2)} estimated
            </p>
          </div>
        ) : (
          <div className="text-left">
            <p className="text-xs font-bold tracking-widest text-muted">REFERENCE</p>
            <p className="mt-2 text-sm text-muted">
              {hydrated
                ? "No request yet. Choose a package or activity to plan a day out."
                : "Loading your request…"}
            </p>
          </div>
        )}
        <h2 className="mt-6 text-left text-sm font-extrabold text-forest">Next steps</h2>
        <p className="mt-2 text-left text-sm leading-relaxed text-muted">
          Our team will contact you to confirm availability and final details.
        </p>
        <Link
          to="/home"
          className="mt-6 inline-flex h-12 w-full items-center justify-center rounded-control bg-ember text-sm font-semibold text-snow"
        >
          Back to Home
        </Link>
      </section>
    </AppShell>
  );
}
