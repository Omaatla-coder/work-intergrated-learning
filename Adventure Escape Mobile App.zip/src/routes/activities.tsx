import { createFileRoute, Link } from "@tanstack/react-router";
import { AppShell } from "@/components/shell";
import { SaveButton } from "@/components/bits";
import { activities, formatRand } from "@/lib/catalog";

export const Route = createFileRoute("/activities")({ component: ActivitiesPage });

function ActivitiesPage() {
  return (
    <AppShell>
      <h1 className="font-display text-3xl font-bold text-ink">Adventure activities</h1>
      <p className="mt-1 text-sm text-muted">Pick an experience to remember.</p>
      <ul className="mt-5 space-y-5">
        {activities.map((item) => (
          <li key={item.id}>
            <div className="relative overflow-hidden rounded-card bg-mist">
              <img src={item.image} alt={item.imageAlt} className="h-28 w-full object-cover" />
              <p className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-ink/75 to-transparent px-3 py-2 text-center text-xs font-bold tracking-widest text-snow">
                {item.badge.toUpperCase()}
              </p>
              <div className="absolute right-3 top-3">
                <SaveButton id={item.id} />
              </div>
            </div>
            <div className="mt-3 flex items-end justify-between gap-3">
              <div>
                <h2 className="font-display text-lg font-bold text-ink">{item.name}</h2>
                <p className="mt-1 text-sm text-muted">{item.tagline}</p>
                <p className="mt-2 text-sm font-extrabold text-forest tabular-nums">
                  {formatRand(item.price)} per person
                </p>
              </div>
              <Link
                to="/book"
                search={{ experience: item.id }}
                className="inline-flex h-11 shrink-0 items-center justify-center rounded-control bg-ember px-4 text-sm font-semibold text-snow"
              >
                Book activity
              </Link>
            </div>
          </li>
        ))}
      </ul>
    </AppShell>
  );
}
