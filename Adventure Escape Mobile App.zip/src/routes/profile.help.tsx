import { createFileRoute, Link } from "@tanstack/react-router";
import { AppShell } from "@/components/shell";

export const Route = createFileRoute("/profile/help")({ component: HelpPage });

const faqs = [
  {
    q: "How do I book?",
    a: "Open Packages or Activities, choose an experience, and send a booking request. Nothing is charged in the app.",
  },
  {
    q: "When is it confirmed?",
    a: "The request is received straight away. Our team contacts you to confirm availability and the final details.",
  },
  {
    q: "How do fees work?",
    a: "The fee calculator adds your choices, takes 5% off when you pick two or more, then adds 15% VAT.",
  },
  {
    q: "Where do we meet?",
    a: "Meeting points in the Western Cape are shared after your booking is confirmed.",
  },
];

function HelpPage() {
  return (
    <AppShell>
      <Link to="/profile" className="text-sm font-semibold text-forest">
        Back to profile
      </Link>
      <h1 className="mt-3 font-display text-3xl font-bold text-ink">Help & support</h1>
      <p className="mt-1 text-sm text-muted">Get assistance from our team.</p>
      <ul className="mt-5 space-y-3">
        {faqs.map((item) => (
          <li key={item.q} className="rounded-card border border-line bg-card p-4">
            <h2 className="text-sm font-extrabold text-ink">{item.q}</h2>
            <p className="mt-1 text-sm leading-relaxed text-muted">{item.a}</p>
          </li>
        ))}
      </ul>
      <a className="mt-5 block text-sm font-semibold text-forest" href="mailto:hello@adventureescapesa.co.za">
        hello@adventureescapesa.co.za
      </a>
      <Link
        to="/contact"
        className="mt-4 inline-flex h-12 w-full items-center justify-center rounded-control bg-ember text-sm font-semibold text-snow"
      >
        Contact our team
      </Link>
    </AppShell>
  );
}
