import { useMemo, useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Check } from "lucide-react";
import { AppShell } from "@/components/shell";
import { PrimaryButton } from "@/components/bits";
import { activities, formatRand, packages, quoteSelected } from "@/lib/catalog";

export const Route = createFileRoute("/fees")({ component: FeesPage });

function FeesPage() {
  const navigate = useNavigate();
  const [selected, setSelected] = useState<string[]>([]);
  const quote = useMemo(() => quoteSelected(selected), [selected]);

  function toggle(id: string) {
    setSelected((current) =>
      current.includes(id) ? current.filter((item) => item !== id) : [...current, id],
    );
  }

  return (
    <AppShell>
      <h1 className="font-display text-3xl font-bold text-ink">Fee calculator</h1>
      <p className="mt-1 text-sm text-muted">Select experiences to estimate your total.</p>

      <fieldset className="mt-5">
        <legend className="text-xs font-bold tracking-wide text-muted">PACKAGES</legend>
        <ul className="mt-2 space-y-2">
          {packages.map((item) => (
            <FeeRow
              key={item.id}
              name={item.name}
              price={formatRand(item.price)}
              checked={selected.includes(item.id)}
              onToggle={() => toggle(item.id)}
            />
          ))}
        </ul>
      </fieldset>

      <fieldset className="mt-4">
        <legend className="text-xs font-bold tracking-wide text-muted">ACTIVITIES</legend>
        <ul className="mt-2 space-y-2">
          {activities.map((item) => (
            <FeeRow
              key={item.id}
              name={item.name}
              price={formatRand(item.price)}
              checked={selected.includes(item.id)}
              onToggle={() => toggle(item.id)}
            />
          ))}
        </ul>
      </fieldset>

      <section className="mt-5 rounded-card bg-ink p-5 text-on-ink">
        <p className="text-xs font-bold tracking-widest text-sun">ESTIMATED TOTAL</p>
        <p className="mt-2 font-display text-4xl font-bold text-snow tabular-nums">
          {formatRand(quote.total, 2)}
        </p>
        <dl className="mt-4 space-y-1.5 text-sm">
          <Row label="Subtotal" value={formatRand(quote.subtotal, 2)} />
          <Row
            label={quote.items.length >= 2 ? "Discount (5%)" : "Discount"}
            value={quote.discount ? `− ${formatRand(quote.discount, 2)}` : formatRand(0, 2)}
          />
          <Row label="VAT (15%)" value={formatRand(quote.vat, 2)} />
        </dl>
        <p className="mt-4 text-xs leading-relaxed text-on-ink">
          Two or more experiences take 5% off the subtotal, then 15% VAT is added. Final quote
          confirmed at booking.
        </p>
      </section>

      <PrimaryButton
        className="mt-5"
        type="button"
        onClick={() =>
          navigate({
            to: "/book",
            search: { experience: quote.items[0]?.id },
          })
        }
      >
        Continue to booking
      </PrimaryButton>
    </AppShell>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-3 text-on-ink">
      <dt>{label}</dt>
      <dd className="font-semibold tabular-nums">{value}</dd>
    </div>
  );
}

function FeeRow({
  name,
  price,
  checked,
  onToggle,
}: {
  name: string;
  price: string;
  checked: boolean;
  onToggle: () => void;
}) {
  return (
    <li>
      <button
        type="button"
        role="checkbox"
        aria-checked={checked}
        onClick={onToggle}
        className={`flex min-h-14 w-full items-center gap-3 rounded-card border bg-card px-3 text-left ${
          checked ? "border-forest" : "border-line"
        }`}
      >
        <span
          className={`grid size-5 shrink-0 place-items-center rounded border-2 border-forest ${
            checked ? "bg-forest text-snow" : "bg-card"
          }`}
          aria-hidden="true"
        >
          {checked ? <Check className="size-3.5" strokeWidth={3} /> : null}
        </span>
        <span className="min-w-0 flex-1 text-sm font-semibold text-ink">{name}</span>
        <span className="text-sm font-extrabold text-forest tabular-nums">{price}</span>
      </button>
    </li>
  );
}
