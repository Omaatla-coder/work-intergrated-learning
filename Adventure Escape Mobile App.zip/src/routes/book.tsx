import { useEffect, useState, type FormEvent } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { AppShell } from "@/components/shell";
import { FieldError, FieldLabel, PrimaryButton } from "@/components/bits";
import {
  activities,
  bookingQuote,
  findExperience,
  formatRand,
  packages,
  prettyDate,
  todayISO,
} from "@/lib/catalog";
import { useAdventure } from "@/lib/adventure-store";

export const Route = createFileRoute("/book")({
  validateSearch: (search: Record<string, unknown>) => ({
    experience: typeof search.experience === "string" ? search.experience : undefined,
  }),
  component: BookPage,
});

type Errors = Partial<Record<"name" | "email" | "phone" | "experience" | "date" | "guests", string>>;

function BookPage() {
  const { experience: preset } = Route.useSearch();
  const navigate = useNavigate();
  const profile = useAdventure((state) => state.profile);
  const addBooking = useAdventure((state) => state.addBooking);

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [experienceId, setExperienceId] = useState(preset ?? "");
  const [date, setDate] = useState("");
  const [guests, setGuests] = useState("2");
  const [errors, setErrors] = useState<Errors>({});
  const [reviewing, setReviewing] = useState(false);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    if (preset && findExperience(preset)) setExperienceId(preset);
  }, [preset]);

  useEffect(() => {
    if (!profile || ready) return;
    setName(profile.name);
    setEmail(profile.email);
    setPhone(profile.phone);
    setReady(true);
  }, [profile, ready]);

  const experience = findExperience(experienceId);
  const guestCount = Number(guests);
  const quote = experience && guestCount >= 1 ? bookingQuote(experience, guestCount) : null;

  function validate() {
    const next: Errors = {};
    if (name.trim().length < 2) next.name = "Enter your full name.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) next.email = "Enter a valid email address.";
    const digits = phone.replace(/\D/g, "");
    if (digits.length < 9 || digits.length > 15) next.phone = "Enter a phone number we can reach.";
    if (!experience) next.experience = "Choose an experience.";
    if (!date) next.date = "Choose a preferred date.";
    else if (date < todayISO()) next.date = "Choose today or a later date.";
    if (!Number.isFinite(guestCount) || guestCount < 1 || guestCount > 20) {
      next.guests = "Enter between 1 and 20 guests.";
    }
    setErrors(next);
    return Object.keys(next).length === 0;
  }

  function review(event: FormEvent) {
    event.preventDefault();
    if (!validate() || !experience || !quote) return;
    setReviewing(true);
  }

  function confirm() {
    if (!experience || !quote) return;
    addBooking({
      name: name.trim(),
      email: email.trim(),
      phone: phone.trim(),
      experienceId: experience.id,
      experienceName: experience.name,
      date,
      guests: quote.guests,
      base: quote.base,
      vat: quote.vat,
      total: quote.total,
    });
    navigate({ to: "/confirmation" });
  }

  return (
    <AppShell>
      <h1 className="font-display text-3xl font-bold text-ink">
        {reviewing ? "Review booking" : "Plan your experience"}
      </h1>
      <p className="mt-1 text-sm text-muted">
        {reviewing ? "Check the details before you send the request." : "Tell us a little about your trip."}
      </p>

      {reviewing && experience && quote ? (
        <section className="mt-5 rounded-card border border-line bg-card p-4">
          <dl className="space-y-3 text-sm">
            <Line label="Experience" value={experience.name} />
            <Line label="Date" value={prettyDate(date)} />
            <Line label="Guests" value={String(quote.guests)} />
            <Line label="Name" value={name.trim()} />
            <Line label="Email" value={email.trim()} />
            <Line label="Phone" value={phone.trim()} />
            <Line
              label={experience.perPerson ? `${quote.guests} × ${formatRand(experience.price)}` : "Package price"}
              value={formatRand(quote.base, 2)}
            />
            <Line label="VAT (15%)" value={formatRand(quote.vat, 2)} />
            <Line label="Estimated total" value={formatRand(quote.total, 2)} strong />
          </dl>
          <p className="mt-4 text-xs leading-relaxed text-muted">
            This is a request, not a payment. Our team confirms availability before anything is due.
            {experience.perPerson
              ? " Activities are priced per person."
              : " This package price covers the group."}
          </p>
          <PrimaryButton className="mt-4" type="button" onClick={confirm}>
            Send booking request
          </PrimaryButton>
          <button
            type="button"
            onClick={() => setReviewing(false)}
            className="mt-3 h-11 w-full text-sm font-semibold text-forest"
          >
            Edit details
          </button>
        </section>
      ) : (
        <form className="mt-5 space-y-4" onSubmit={review} noValidate>
          <div>
            <FieldLabel htmlFor="full-name">Full name</FieldLabel>
            <input
              id="full-name"
              className={inputClass}
              placeholder="Enter your name"
              autoComplete="name"
              value={name}
              onChange={(event) => setName(event.target.value)}
            />
            <FieldError>{errors.name}</FieldError>
          </div>
          <div>
            <FieldLabel htmlFor="email">Email address</FieldLabel>
            <input
              id="email"
              type="email"
              className={inputClass}
              placeholder="you@example.com"
              autoComplete="email"
              value={email}
              onChange={(event) => setEmail(event.target.value)}
            />
            <FieldError>{errors.email}</FieldError>
          </div>
          <div>
            <FieldLabel htmlFor="phone">Phone number</FieldLabel>
            <input
              id="phone"
              type="tel"
              className={inputClass}
              placeholder="+27"
              autoComplete="tel"
              inputMode="tel"
              value={phone}
              onChange={(event) => setPhone(event.target.value)}
            />
            <FieldError>{errors.phone}</FieldError>
          </div>
          <div>
            <FieldLabel htmlFor="experience">Choose experience</FieldLabel>
            <select
              id="experience"
              className={inputClass}
              value={experienceId}
              onChange={(event) => setExperienceId(event.target.value)}
            >
              <option value="">Select a package</option>
              <optgroup label="Packages">
                {packages.map((item) => (
                  <option key={item.id} value={item.id}>
                    {item.name} · {formatRand(item.price)}
                  </option>
                ))}
              </optgroup>
              <optgroup label="Activities">
                {activities.map((item) => (
                  <option key={item.id} value={item.id}>
                    {item.name} · {formatRand(item.price)} pp
                  </option>
                ))}
              </optgroup>
            </select>
            <FieldError>{errors.experience}</FieldError>
          </div>
          <div>
            <FieldLabel htmlFor="date">Preferred date</FieldLabel>
            <input
              id="date"
              type="date"
              min={todayISO()}
              className={inputClass}
              value={date}
              onChange={(event) => setDate(event.target.value)}
            />
            <FieldError>{errors.date}</FieldError>
          </div>
          <div>
            <FieldLabel htmlFor="guests">Number of guests</FieldLabel>
            <input
              id="guests"
              type="number"
              min={1}
              max={20}
              inputMode="numeric"
              className={inputClass}
              value={guests}
              onChange={(event) => setGuests(event.target.value)}
            />
            <FieldError>{errors.guests}</FieldError>
          </div>
          <PrimaryButton type="submit">Review booking</PrimaryButton>
        </form>
      )}
    </AppShell>
  );
}

const inputClass =
  "h-12 w-full rounded-control border border-line bg-card px-3.5 text-base text-ink outline-none transition placeholder:text-faint focus:border-forest focus:ring-2 focus:ring-forest/25";

function Line({ label, value, strong }: { label: string; value: string; strong?: boolean }) {
  return (
    <div className="flex items-start justify-between gap-4">
      <dt className="text-muted">{label}</dt>
      <dd className={`text-right text-ink ${strong ? "font-extrabold" : "font-semibold"}`}>{value}</dd>
    </div>
  );
}
