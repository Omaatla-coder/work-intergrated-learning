import { createFileRoute, Link } from "@tanstack/react-router";
import { AppShell } from "@/components/shell";
import { SaveButton } from "@/components/bits";
import { findExperience, formatRand } from "@/lib/catalog";
import { useAdventure } from "@/lib/adventure-store";

export const Route = createFileRoute("/profile/saved")({ component: SavedPage });

function SavedPage() {
  const hydrated = useAdventure((state) => state.hydrated);
  const saved = useAdventure((state) => state.saved);
  const items = saved.map((id) => findExperience(id)).filter((item) => item !== undefined);

  return (
    <AppShell>
      <Link to="/profile" className="text-sm font-semibold text-forest">
        Back to profile
      </Link>
      <h1 className="mt-3 font-display text-3xl font-bold text-ink">Saved adventures</h1>
      <p className="mt-1 text-sm text-muted">Keep favourites in one place.</p>

      {!hydrated ? null : items.length === 0 ? (
        <div className="mt-6 rounded-card border border-line bg-card p-5">
          <p className="text-sm text-muted">Nothing saved yet. Tap the heart on a package or activity.</p>
          <Link to="/activities" className="mt-3 inline-flex text-sm font-semibold text-forest">
            See activities
          </Link>
        </div>
      ) : (
        <ul className="mt-5 space-y-3">
          {items.map((item) => (
            <li key={item.id} className="flex gap-3 rounded-card border border-line bg-card p-2">
              <img src={item.image} alt="" className="h-20 w-20 rounded-card object-cover" />
              <div className="min-w-0 flex-1 py-1">
                <h2 className="font-display text-base font-bold text-ink">{item.name}</h2>
                <p className="text-sm font-extrabold text-forest tabular-nums">
                  {formatRand(item.price)}
                  {item.perPerson ? " pp" : ""}
                </p>
                {item.kind === "package" ? (
                  <Link to="/packages/$id" params={{ id: item.id }} className="mt-1 inline-flex text-sm font-semibold text-forest">
                    View details
                  </Link>
                ) : (
                  <Link to="/book" search={{ experience: item.id }} className="mt-1 inline-flex text-sm font-semibold text-forest">
                    Book activity
                  </Link>
                )}
              </div>
              <SaveButton id={item.id} />
            </li>
          ))}
        </ul>
      )}
    </AppShell>
  );
}
