import { C as require_jsx_runtime, b as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { n as Route$5 } from "./_ssr/router-DtzZVmaY.mjs";
import { a as findExperience, o as formatRand, t as AppShell } from "./_ssr/shell-CrZ6Y0oo.mjs";
import { a as SaveButton } from "./_ssr/bits-BgzWzA0I.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_id-3BrMtjHx.js
var import_jsx_runtime = require_jsx_runtime();
function PackageDetail() {
	const { id } = Route$5.useParams();
	const item = findExperience(id);
	if (!item || item.kind !== "package") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-3xl font-bold text-ink",
			children: "Package not found"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-muted",
			children: "That adventure is not on the list."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/packages",
			className: "mt-6 inline-flex font-semibold text-forest",
			children: "Back to packages"
		})
	] });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "relative overflow-hidden rounded-card bg-mist",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: item.image,
					alt: item.imageAlt,
					className: "h-48 w-full object-cover"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "absolute inset-x-0 bottom-0 bg-gradient-to-t from-ink/80 to-transparent px-3 py-3 text-center text-xs font-bold tracking-widest text-snow",
					children: item.badge.toUpperCase()
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute right-3 top-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SaveButton, { id: item.id })
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-5 font-display text-3xl font-bold leading-tight text-ink",
			children: item.name
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mt-3 text-sm font-extrabold text-forest",
			children: "Package overview"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-3 space-y-2.5 text-sm text-muted",
			children: item.overview.map((point) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					"aria-hidden": "true",
					children: "•"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: point })]
			}, point))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("hr", { className: "my-5 border-line" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: "Package price"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 font-display text-3xl font-bold text-ink tabular-nums",
			children: formatRand(item.price)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-xs text-muted",
			children: "Priced for the group. Guest count is confirmed when you book."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/book",
			search: { experience: item.id },
			className: "mt-5 inline-flex h-12 w-full items-center justify-center rounded-control bg-ember text-sm font-semibold text-snow transition hover:bg-ember-deep active:scale-95",
			children: "Continue to booking"
		})
	] });
}
//#endregion
export { PackageDetail as component };
