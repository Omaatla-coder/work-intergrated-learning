import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Y as require_react, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as AppShell } from "./shell-CrZ6Y0oo.mjs";
import { i as PrimaryButton, n as FieldLabel, t as FieldError } from "./bits-BgzWzA0I.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contact-CG5c4_yK.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var inputClass = "w-full rounded-control border border-line bg-card px-3.5 text-base text-ink outline-none transition placeholder:text-faint focus:border-forest focus:ring-2 focus:ring-forest/25";
function ContactPage() {
	const [name, setName] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [message, setMessage] = (0, import_react.useState)("");
	const [errors, setErrors] = (0, import_react.useState)({});
	const [sent, setSent] = (0, import_react.useState)(false);
	function submit(event) {
		event.preventDefault();
		const next = {};
		if (name.trim().length < 2) next.name = "Enter your name.";
		if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) next.email = "Enter a valid email address.";
		if (message.trim().length < 8) next.message = "Tell us a little more so we can help.";
		setErrors(next);
		if (Object.keys(next).length === 0) setSent(true);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-3xl font-bold text-ink",
			children: "Contact our team"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted",
			children: "We are happy to help plan your escape."
		}),
		sent ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-6 rounded-card border border-line bg-card p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-2xl font-bold text-ink",
					children: "Message received"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-sm leading-relaxed text-muted",
					children: [
						"Thanks, ",
						name.trim().split(" ")[0],
						". We will reply to ",
						email.trim(),
						" as soon as we can."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "mt-4 text-sm font-semibold text-forest",
					onClick: () => {
						setSent(false);
						setMessage("");
					},
					children: "Send another message"
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "mt-5 space-y-4",
			onSubmit: submit,
			noValidate: true,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
						htmlFor: "contact-name",
						children: "Name"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "contact-name",
						className: `${inputClass} h-12`,
						placeholder: "Your full name",
						autoComplete: "name",
						value: name,
						onChange: (event) => setName(event.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { children: errors.name })
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
						htmlFor: "contact-email",
						children: "Email"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "contact-email",
						type: "email",
						className: `${inputClass} h-12`,
						placeholder: "you@example.com",
						autoComplete: "email",
						value: email,
						onChange: (event) => setEmail(event.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { children: errors.email })
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
						htmlFor: "contact-message",
						children: "Message"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						id: "contact-message",
						className: `${inputClass} min-h-24 py-3`,
						placeholder: "How can we help?",
						value: message,
						onChange: (event) => setMessage(event.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { children: errors.message })
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
					type: "submit",
					children: "Send message"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-extrabold text-forest",
					children: "Email"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					className: "mt-1 block text-sm text-ink",
					href: "mailto:hello@adventureescapesa.co.za",
					children: "hello@adventureescapesa.co.za"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/location",
					className: "mt-4 block text-sm text-muted underline decoration-line underline-offset-4",
					children: "Based in the Western Cape, South Africa"
				})
			]
		})
	] });
}
//#endregion
export { ContactPage as component };
