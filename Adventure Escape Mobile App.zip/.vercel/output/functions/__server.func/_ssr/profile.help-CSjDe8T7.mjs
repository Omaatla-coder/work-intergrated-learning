import { C as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as AppShell } from "./shell-CrZ6Y0oo.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/profile.help-CSjDe8T7.js
var import_jsx_runtime = require_jsx_runtime();
var faqs = [
	{
		q: "How do I book?",
		a: "Open Packages or Activities, choose an experience, and send a booking request. Nothing is charged in the app."
	},
	{
		q: "When is it confirmed?",
		a: "The request is received straight away. Our team contacts you to confirm availability and the final details."
	},
	{
		q: "How do fees work?",
		a: "The fee calculator adds your choices, takes 5% off when you pick two or more, then adds 15% VAT."
	},
	{
		q: "Where do we meet?",
		a: "Meeting points in the Western Cape are shared after your booking is confirmed."
	}
];
function HelpPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/profile",
			className: "text-sm font-semibold text-forest",
			children: "Back to profile"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-3 font-display text-3xl font-bold text-ink",
			children: "Help & support"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted",
			children: "Get assistance from our team."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-5 space-y-3",
			children: faqs.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "rounded-card border border-line bg-card p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-extrabold text-ink",
					children: item.q
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm leading-relaxed text-muted",
					children: item.a
				})]
			}, item.q))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
			className: "mt-5 block text-sm font-semibold text-forest",
			href: "mailto:hello@adventureescapesa.co.za",
			children: "hello@adventureescapesa.co.za"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/contact",
			className: "mt-4 inline-flex h-12 w-full items-center justify-center rounded-control bg-ember text-sm font-semibold text-snow",
			children: "Contact our team"
		})
	] });
}
//#endregion
export { HelpPage as component };
