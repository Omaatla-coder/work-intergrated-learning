import { C as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as useAdventure, l as prettyDate, o as formatRand, t as AppShell } from "./shell-CrZ6Y0oo.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/profile.bookings-D3YgKuja.js
var import_jsx_runtime = require_jsx_runtime();
function BookingsPage() {
	const hydrated = useAdventure((state) => state.hydrated);
	const bookings = useAdventure((state) => state.bookings);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/profile",
			className: "text-sm font-semibold text-forest",
			children: "Back to profile"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-3 font-display text-3xl font-bold text-ink",
			children: "My bookings"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted",
			children: "Requests saved on this device."
		}),
		!hydrated ? null : bookings.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 rounded-card border border-line bg-card p-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "No adventures booked yet."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/packages",
				className: "mt-3 inline-flex text-sm font-semibold text-forest",
				children: "Browse packages"
			})]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-5 space-y-3",
			children: bookings.map((booking) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "rounded-card border border-line bg-card p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-bold tracking-widest text-muted",
						children: booking.reference
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-1 font-display text-lg font-bold text-ink",
						children: booking.experienceName
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted",
						children: [
							prettyDate(booking.date),
							" · ",
							booking.guests,
							" ",
							booking.guests === 1 ? "guest" : "guests"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm font-extrabold text-forest tabular-nums",
						children: formatRand(booking.total, 2)
					})
				]
			}, booking.id))
		})
	] });
}
//#endregion
export { BookingsPage as component };
