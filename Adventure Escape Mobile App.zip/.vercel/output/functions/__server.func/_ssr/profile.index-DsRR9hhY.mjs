import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Y as require_react, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as ChevronRight } from "../_libs/lucide-react.mjs";
import { f as useAdventure, s as initialsFrom, t as AppShell } from "./shell-CrZ6Y0oo.mjs";
import { n as FieldLabel, r as InkButton, t as FieldError } from "./bits-BgzWzA0I.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/profile.index-DsRR9hhY.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var rows = [
	{
		to: "/profile/details",
		title: "Personal details",
		note: "Manage your contact information"
	},
	{
		to: "/profile/bookings",
		title: "My bookings",
		note: "View upcoming experiences"
	},
	{
		to: "/profile/saved",
		title: "Saved adventures",
		note: "Keep favourites in one place"
	},
	{
		to: "/profile/help",
		title: "Help & support",
		note: "Get assistance from our team"
	}
];
var inputClass = "h-12 w-full rounded-control border border-line bg-card px-3.5 text-base text-ink outline-none placeholder:text-faint focus:border-forest focus:ring-2 focus:ring-forest/25";
function ProfilePage() {
	const hydrated = useAdventure((state) => state.hydrated);
	const profile = useAdventure((state) => state.profile);
	const setProfile = useAdventure((state) => state.setProfile);
	const signOut = useAdventure((state) => state.signOut);
	const [open, setOpen] = (0, import_react.useState)(false);
	const [name, setName] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	const signedIn = hydrated && profile;
	const first = signedIn ? profile.name.trim().split(/\s+/)[0] : "";
	function save(event) {
		event.preventDefault();
		if (name.trim().length < 2) {
			setError("Enter the name you want on your bookings.");
			return;
		}
		if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
			setError("Enter a valid email address.");
			return;
		}
		setProfile({
			name: name.trim(),
			email: email.trim(),
			phone: phone.trim()
		});
		setOpen(false);
		setError("");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-3xl font-bold text-ink",
			children: "Your adventure profile"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-5 flex items-center gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid size-16 place-items-center rounded-full bg-mist text-lg font-extrabold text-forest",
				children: signedIn ? initialsFrom(profile.name) : "AE"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-lg font-bold text-ink",
				children: signedIn ? `Welcome, ${first}` : "Welcome, explorer"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: signedIn ? profile.email : "Sign in to manage your plans"
			})] })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-6 space-y-3",
			children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: row.to,
				className: "flex min-h-16 items-center justify-between rounded-card border border-line bg-card px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block text-sm font-extrabold text-ink",
					children: row.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mt-0.5 block text-xs text-muted",
					children: row.note
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, {
					className: "size-5 text-forest",
					"aria-hidden": "true"
				})]
			}) }, row.to))
		}),
		signedIn ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: signOut,
			className: "mt-6 h-12 w-full rounded-control border border-line bg-card text-sm font-semibold text-ink",
			children: "Sign out"
		}) : open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "mt-6 space-y-3 rounded-card border border-line bg-card p-4",
			onSubmit: save,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-bold text-ink",
					children: "Create your profile"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted",
					children: "Saved on this device so booking forms can use it."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
					htmlFor: "profile-name",
					children: "Full name"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					id: "profile-name",
					className: inputClass,
					value: name,
					onChange: (event) => setName(event.target.value)
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
					htmlFor: "profile-email",
					children: "Email"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					id: "profile-email",
					type: "email",
					className: inputClass,
					value: email,
					onChange: (event) => setEmail(event.target.value)
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
					htmlFor: "profile-phone",
					children: "Phone"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					id: "profile-phone",
					type: "tel",
					className: inputClass,
					placeholder: "+27",
					value: phone,
					onChange: (event) => setPhone(event.target.value)
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { children: error }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InkButton, {
					type: "submit",
					children: "Save profile"
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InkButton, {
			className: "mt-6",
			type: "button",
			onClick: () => setOpen(true),
			children: "Sign in / Create account"
		})
	] });
}
//#endregion
export { ProfilePage as component };
