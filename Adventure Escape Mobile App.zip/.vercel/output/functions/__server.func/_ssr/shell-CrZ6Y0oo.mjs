import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Y as require_react, b as Link, p as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Mountain, c as LayoutGrid, i as Receipt, l as House, s as Mail } from "../_libs/lucide-react.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/shell-CrZ6Y0oo.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var VAT_RATE = .15;
var MULTI_DISCOUNT = .05;
var experiences = [
	{
		id: "ultimate",
		kind: "package",
		name: "Ultimate Adventure Day",
		shortName: "Ultimate Day",
		tagline: "A full day of outdoor thrills",
		price: 1500,
		perPerson: false,
		image: "/photos/ridge.jpg",
		imageAlt: "Sunrise on a Western Cape mountain ridge above the coast",
		badge: "Ultimate day",
		overview: [
			"Guided zipline and trail combo",
			"Coastal lookout stop",
			"Local adventure guide",
			"Safety briefing and gear check"
		]
	},
	{
		id: "family",
		kind: "package",
		name: "Family Explorer Package",
		shortName: "Family Fun",
		tagline: "Shared fun for all ages",
		price: 1500,
		perPerson: false,
		image: "/photos/family.jpg",
		imageAlt: "A fynbos hiking trail in the Western Cape",
		badge: "Family fun",
		overview: [
			"Gentle trails suited to families",
			"Scenic stops and photo moments",
			"A guide who keeps an easy pace",
			"Gear guidance for every age"
		]
	},
	{
		id: "mountain",
		kind: "package",
		name: "Mountain Adventure Package",
		shortName: "Mountain",
		tagline: "Scenic trails and fresh air",
		price: 1500,
		perPerson: false,
		image: "/photos/cape.jpg",
		imageAlt: "Sandstone mountains and fynbos in the Western Cape",
		badge: "Mountain",
		overview: [
			"Guided mountain outing",
			"Scenic stops and photo moments",
			"Helpful local adventure guide",
			"Suitable gear guidance included"
		]
	},
	{
		id: "corporate",
		kind: "package",
		name: "Corporate Team Challenge",
		shortName: "Team Challenge",
		tagline: "Build trust beyond the office",
		price: 1500,
		perPerson: false,
		image: "/photos/team.jpg",
		imageAlt: "An outdoor team challenge course with mountains behind it",
		badge: "Team challenge",
		overview: [
			"Facilitated team challenges",
			"Shared problem-solving outdoors",
			"A dedicated group guide",
			"A short debrief before you head back"
		]
	},
	{
		id: "zipline",
		kind: "activity",
		name: "Ziplining Adventure",
		shortName: "Ziplining",
		tagline: "Fly above the forest canopy",
		price: 750,
		perPerson: true,
		image: "/photos/zipline.jpg",
		imageAlt: "A zipline cable through indigenous forest canopy",
		badge: "Zipline",
		overview: [
			"Guided canopy zipline",
			"Harness, helmet, and briefing",
			"Suitable for first-time flyers",
			"Forest lookout at the end of the line"
		]
	},
	{
		id: "kayak",
		kind: "activity",
		name: "Kayaking Experience",
		shortName: "Kayaking",
		tagline: "Paddle across beautiful waters",
		price: 750,
		perPerson: true,
		image: "/photos/kayak.jpg",
		imageAlt: "A sea kayak on calm water beside sandstone cliffs",
		badge: "Kayaking",
		overview: [
			"Calm-water paddle with a guide",
			"Kayak and paddle provided",
			"Time to drift and take photos",
			"Safety briefing before you launch"
		]
	},
	{
		id: "climb",
		kind: "activity",
		name: "Rock Climbing Session",
		shortName: "Rock climbing",
		tagline: "Challenge yourself safely",
		price: 750,
		perPerson: true,
		image: "/photos/climb.jpg",
		imageAlt: "A sunlit sandstone climbing cliff with safety ropes",
		badge: "Rock climbing",
		overview: [
			"Introductory climbs on solid rock",
			"Harness and helmet included",
			"A guide on the rope the whole time",
			"Pace set for your group"
		]
	}
];
var packages = experiences.filter((item) => item.kind === "package");
var activities = experiences.filter((item) => item.kind === "activity");
function findExperience(id) {
	if (!id) return void 0;
	return experiences.find((item) => item.id === id);
}
function formatRand(amount, decimals = 0) {
	return `R${amount.toLocaleString("en-US", {
		minimumFractionDigits: decimals,
		maximumFractionDigits: decimals
	})}`;
}
function quoteSelected(ids) {
	const items = ids.map((id) => findExperience(id)).filter((item) => Boolean(item));
	const subtotal = items.reduce((sum, item) => sum + item.price, 0);
	const discount = items.length >= 2 ? roundMoney(subtotal * MULTI_DISCOUNT) : 0;
	const afterDiscount = roundMoney(subtotal - discount);
	const vat = roundMoney(afterDiscount * VAT_RATE);
	return {
		items,
		subtotal,
		discount,
		vat,
		total: roundMoney(afterDiscount + vat)
	};
}
function bookingQuote(experience, guests) {
	const safeGuests = Math.max(1, guests);
	const base = experience.perPerson ? roundMoney(experience.price * safeGuests) : experience.price;
	const vat = roundMoney(base * VAT_RATE);
	return {
		base,
		vat,
		total: roundMoney(base + vat),
		guests: safeGuests
	};
}
function roundMoney(value) {
	return Math.round(value * 100) / 100;
}
function initialsFrom(name) {
	const parts = name.trim().split(/\s+/).filter(Boolean);
	if (parts.length === 0) return "AE";
	if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
	return `${parts[0][0]}${parts[parts.length - 1][0]}`.toUpperCase();
}
function prettyDate(iso) {
	const [year, month, day] = iso.split("-").map(Number);
	if (!year || !month || !day) return iso;
	return new Date(year, month - 1, day).toLocaleDateString("en-GB", {
		day: "numeric",
		month: "long",
		year: "numeric"
	});
}
function todayISO() {
	const now = /* @__PURE__ */ new Date();
	const month = String(now.getMonth() + 1).padStart(2, "0");
	const day = String(now.getDate()).padStart(2, "0");
	return `${now.getFullYear()}-${month}-${day}`;
}
var useAdventure = create()(persist((set, get) => ({
	hydrated: false,
	profile: null,
	bookings: [],
	saved: [],
	setProfile: (profile) => set({ profile }),
	signOut: () => set({ profile: null }),
	toggleSaved: (id) => {
		const saved = get().saved;
		set({ saved: saved.includes(id) ? saved.filter((item) => item !== id) : [...saved, id] });
	},
	addBooking: (draft) => {
		const reference = `AES-2026-${String(get().bookings.length + 1).padStart(3, "0")}`;
		const booking = {
			...draft,
			id: crypto.randomUUID(),
			reference,
			createdAt: (/* @__PURE__ */ new Date()).toISOString()
		};
		set({ bookings: [booking, ...get().bookings] });
		return booking;
	}
}), {
	name: "adventure-escape-sa",
	partialize: (state) => ({
		profile: state.profile,
		bookings: state.bookings,
		saved: state.saved
	})
}));
var tabs = [
	{
		to: "/home",
		label: "Home",
		icon: House
	},
	{
		to: "/packages",
		label: "Packages",
		icon: LayoutGrid
	},
	{
		to: "/activities",
		label: "Activities",
		icon: Mountain
	},
	{
		to: "/fees",
		label: "Fees",
		icon: Receipt
	},
	{
		to: "/contact",
		label: "Contact",
		icon: Mail
	}
];
function Stage({ children }) {
	(0, import_react.useEffect)(() => {
		const finish = () => useAdventure.setState({ hydrated: true });
		if (useAdventure.persist.hasHydrated()) finish();
		return useAdventure.persist.onFinishHydration(finish);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-dvh w-full overflow-hidden bg-stage text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "hidden min-w-0 flex-1 flex-col justify-end px-10 py-14 lg:flex",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold tracking-widest text-sun",
						children: "WESTERN CAPE"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-xs font-display text-4xl font-semibold leading-tight text-snow",
						children: "Adventure Escape SA"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-xs text-sm leading-relaxed text-on-ink",
						children: "Guided days outside, from peninsula trails to quiet water. Founded in 2024 by Liam Daniels."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex h-dvh w-full max-w-md shrink-0 flex-col bg-paper",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
				className: "hidden min-w-0 flex-1 items-center justify-start px-8 lg:flex",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
					className: "w-full max-w-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/photos/aerial.jpg",
						alt: "Aerial view of the Cape Peninsula coastline",
						className: "h-80 w-full rounded-card object-cover"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
						className: "mt-3 text-xs font-semibold tracking-widest text-sun",
						children: "CAPE PENINSULA"
					})]
				})
			})
		]
	});
}
function AppHeader() {
	const hydrated = useAdventure((state) => state.hydrated);
	const profile = useAdventure((state) => state.profile);
	const initials = hydrated && profile ? initialsFrom(profile.name) : "AE";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "flex shrink-0 items-center justify-between bg-ink px-5 py-3.5 text-on-ink",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/home",
			className: "block rounded-md",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-semibold tracking-widest text-sun",
				children: "ADVENTURE"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-xl font-bold leading-none text-snow",
				children: "Escape SA"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/profile",
			"aria-label": "Your adventure profile",
			className: "grid size-11 place-items-center rounded-full bg-forest text-xs font-bold text-snow",
			children: initials
		})]
	});
}
function BottomNav() {
	const pathname = useRouterState({ select: (state) => state.location.pathname });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
		className: "nav-pad shrink-0 border-t border-line bg-card",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "grid grid-cols-5",
			children: tabs.map((tab) => {
				const active = pathname === tab.to;
				const Icon = tab.icon;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: tab.to,
					className: `flex min-h-14 flex-col items-center justify-center gap-1 text-xs font-semibold ${active ? "text-ember" : "text-muted"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
						className: "size-5",
						strokeWidth: 2.2,
						"aria-hidden": "true"
					}), tab.label]
				}) }, tab.to);
			})
		})
	});
}
function AppShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Stage, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppHeader, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
			className: "device-scroll min-h-0 flex-1 overflow-y-auto px-5 py-5",
			children
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BottomNav, {})
	] });
}
//#endregion
export { findExperience as a, packages as c, todayISO as d, useAdventure as f, bookingQuote as i, prettyDate as l, Stage as n, formatRand as o, activities as r, initialsFrom as s, AppShell as t, quoteSelected as u };
