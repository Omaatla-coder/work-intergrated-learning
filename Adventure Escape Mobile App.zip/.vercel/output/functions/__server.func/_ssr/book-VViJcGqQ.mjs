import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Y as require_react, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as Route$13 } from "./router-DtzZVmaY.mjs";
import { a as findExperience, c as packages, d as todayISO, f as useAdventure, i as bookingQuote, l as prettyDate, o as formatRand, r as activities, t as AppShell } from "./shell-CrZ6Y0oo.mjs";
import { i as PrimaryButton, n as FieldLabel, t as FieldError } from "./bits-BgzWzA0I.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/book-VViJcGqQ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function BookPage() {
	const { experience: preset } = Route$13.useSearch();
	const navigate = useNavigate();
	const profile = useAdventure((state) => state.profile);
	const addBooking = useAdventure((state) => state.addBooking);
	const [name, setName] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [experienceId, setExperienceId] = (0, import_react.useState)(preset ?? "");
	const [date, setDate] = (0, import_react.useState)("");
	const [guests, setGuests] = (0, import_react.useState)("2");
	const [errors, setErrors] = (0, import_react.useState)({});
	const [reviewing, setReviewing] = (0, import_react.useState)(false);
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (preset && findExperience(preset)) setExperienceId(preset);
	}, [preset]);
	(0, import_react.useEffect)(() => {
		if (!profile || ready) return;
		setName(profile.name);
		setEmail(profile.email);
		setPhone(profile.phone);
		setReady(true);
	}, [profile, ready]);
	const experience = findExperience(experienceId);
	const guestCount = Number(guests);
	const quote = experience && guestCount >= 1 ? bookingQuote(experience, guestCount) : null;
	function validate() {
		const next = {};
		if (name.trim().length < 2) next.name = "Enter your full name.";
		if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) next.email = "Enter a valid email address.";
		const digits = phone.replace(/\D/g, "");
		if (digits.length < 9 || digits.length > 15) next.phone = "Enter a phone number we can reach.";
		if (!experience) next.experience = "Choose an experience.";
		if (!date) next.date = "Choose a preferred date.";
		else if (date < todayISO()) next.date = "Choose today or a later date.";
		if (!Number.isFinite(guestCount) || guestCount < 1 || guestCount > 20) next.guests = "Enter between 1 and 20 guests.";
		setErrors(next);
		return Object.keys(next).length === 0;
	}
	function review(event) {
		event.preventDefault();
		if (!validate() || !experience || !quote) return;
		setReviewing(true);
	}
	function confirm() {
		if (!experience || !quote) return;
		addBooking({
			name: name.trim(),
			email: email.trim(),
			phone: phone.trim(),
			experienceId: experience.id,
			experienceName: experience.name,
			date,
			guests: quote.guests,
			base: quote.base,
			vat: quote.vat,
			total: quote.total
		});
		navigate({ to: "/confirmation" });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-3xl font-bold text-ink",
			children: reviewing ? "Review booking" : "Plan your experience"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted",
			children: reviewing ? "Check the details before you send the request." : "Tell us a little about your trip."
		}),
		reviewing && experience && quote ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-5 rounded-card border border-line bg-card p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "space-y-3 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
							label: "Experience",
							value: experience.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
							label: "Date",
							value: prettyDate(date)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
							label: "Guests",
							value: String(quote.guests)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
							label: "Name",
							value: name.trim()
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
							label: "Email",
							value: email.trim()
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
							label: "Phone",
							value: phone.trim()
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
							label: experience.perPerson ? `${quote.guests} × ${formatRand(experience.price)}` : "Package price",
							value: formatRand(quote.base, 2)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
							label: "VAT (15%)",
							value: formatRand(quote.vat, 2)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
							label: "Estimated total",
							value: formatRand(quote.total, 2),
							strong: true
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-4 text-xs leading-relaxed text-muted",
					children: ["This is a request, not a payment. Our team confirms availability before anything is due.", experience.perPerson ? " Activities are priced per person." : " This package price covers the group."]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
					className: "mt-4",
					type: "button",
					onClick: confirm,
					children: "Send booking request"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setReviewing(false),
					className: "mt-3 h-11 w-full text-sm font-semibold text-forest",
					children: "Edit details"
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "mt-5 space-y-4",
			onSubmit: review,
			noValidate: true,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
						htmlFor: "full-name",
						children: "Full name"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "full-name",
						className: inputClass,
						placeholder: "Enter your name",
						autoComplete: "name",
						value: name,
						onChange: (event) => setName(event.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { children: errors.name })
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
						htmlFor: "email",
						children: "Email address"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "email",
						type: "email",
						className: inputClass,
						placeholder: "you@example.com",
						autoComplete: "email",
						value: email,
						onChange: (event) => setEmail(event.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { children: errors.email })
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
						htmlFor: "phone",
						children: "Phone number"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "phone",
						type: "tel",
						className: inputClass,
						placeholder: "+27",
						autoComplete: "tel",
						inputMode: "tel",
						value: phone,
						onChange: (event) => setPhone(event.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { children: errors.phone })
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
						htmlFor: "experience",
						children: "Choose experience"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						id: "experience",
						className: inputClass,
						value: experienceId,
						onChange: (event) => setExperienceId(event.target.value),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "Select a package"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("optgroup", {
								label: "Packages",
								children: packages.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
									value: item.id,
									children: [
										item.name,
										" · ",
										formatRand(item.price)
									]
								}, item.id))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("optgroup", {
								label: "Activities",
								children: activities.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
									value: item.id,
									children: [
										item.name,
										" · ",
										formatRand(item.price),
										" pp"
									]
								}, item.id))
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { children: errors.experience })
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
						htmlFor: "date",
						children: "Preferred date"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "date",
						type: "date",
						min: todayISO(),
						className: inputClass,
						value: date,
						onChange: (event) => setDate(event.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { children: errors.date })
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
						htmlFor: "guests",
						children: "Number of guests"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "guests",
						type: "number",
						min: 1,
						max: 20,
						inputMode: "numeric",
						className: inputClass,
						value: guests,
						onChange: (event) => setGuests(event.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { children: errors.guests })
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
					type: "submit",
					children: "Review booking"
				})
			]
		})
	] });
}
var inputClass = "h-12 w-full rounded-control border border-line bg-card px-3.5 text-base text-ink outline-none transition placeholder:text-faint focus:border-forest focus:ring-2 focus:ring-forest/25";
function Line({ label, value, strong }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-start justify-between gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: `text-right text-ink ${strong ? "font-extrabold" : "font-semibold"}`,
			children: value
		})]
	});
}
//#endregion
export { BookPage as component };
