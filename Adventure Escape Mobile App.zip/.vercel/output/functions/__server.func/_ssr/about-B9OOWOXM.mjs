import { C as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as Compass, r as ShieldCheck, t as Users } from "../_libs/lucide-react.mjs";
import { t as AppShell } from "./shell-CrZ6Y0oo.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/about-B9OOWOXM.js
var import_jsx_runtime = require_jsx_runtime();
var reasons = [
	{
		icon: Compass,
		text: "Friendly local guides"
	},
	{
		icon: Users,
		text: "Experiences for every group"
	},
	{
		icon: ShieldCheck,
		text: "Safety-first planning"
	}
];
function AboutPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "relative overflow-hidden rounded-card bg-mist",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: "/photos/family.jpg",
				alt: "A trail through Western Cape fynbos",
				className: "h-40 w-full object-cover"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "absolute inset-x-0 bottom-0 bg-gradient-to-t from-ink/75 to-transparent px-3 py-3 text-center text-xs font-bold tracking-widest text-snow",
				children: "OUR STORY"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-6 font-display text-3xl font-bold leading-tight text-ink",
			children: "Adventure with purpose"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mt-4 text-lg font-extrabold text-forest",
			children: "Our Story"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm leading-relaxed text-muted",
			children: "Founded in 2024 by Liam Daniels, Adventure Escape SA creates memorable guided outdoor experiences across the beautiful Western Cape."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mt-6 font-display text-xl font-bold text-ink",
			children: "Why choose us?"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-3 space-y-3",
			children: reasons.map((reason) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex items-center gap-3 text-sm font-semibold text-forest",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(reason.icon, {
					className: "size-5 shrink-0",
					"aria-hidden": "true"
				}), reason.text]
			}, reason.text))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/packages",
			className: "mt-8 inline-flex h-12 items-center justify-center rounded-control bg-ember px-6 text-sm font-semibold text-snow transition hover:bg-ember-deep active:scale-95",
			children: "Explore our packages"
		})
	] });
}
//#endregion
export { AboutPage as component };
