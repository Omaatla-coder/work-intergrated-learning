import { C as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as formatRand, r as activities, t as AppShell } from "./shell-CrZ6Y0oo.mjs";
import { a as SaveButton } from "./bits-BgzWzA0I.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/activities-ER2FmnjL.js
var import_jsx_runtime = require_jsx_runtime();
function ActivitiesPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-3xl font-bold text-ink",
			children: "Adventure activities"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted",
			children: "Pick an experience to remember."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-5 space-y-5",
			children: activities.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative overflow-hidden rounded-card bg-mist",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: item.image,
						alt: item.imageAlt,
						className: "h-28 w-full object-cover"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "absolute inset-x-0 bottom-0 bg-gradient-to-t from-ink/75 to-transparent px-3 py-2 text-center text-xs font-bold tracking-widest text-snow",
						children: item.badge.toUpperCase()
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "absolute right-3 top-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SaveButton, { id: item.id })
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-lg font-bold text-ink",
						children: item.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: item.tagline
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm font-extrabold text-forest tabular-nums",
						children: [formatRand(item.price), " per person"]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/book",
					search: { experience: item.id },
					className: "inline-flex h-11 shrink-0 items-center justify-center rounded-control bg-ember px-4 text-sm font-semibold text-snow",
					children: "Book activity"
				})]
			})] }, item.id))
		})
	] });
}
//#endregion
export { ActivitiesPage as component };
