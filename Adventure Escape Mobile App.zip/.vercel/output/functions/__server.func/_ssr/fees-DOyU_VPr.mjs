import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Y as require_react, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { p as Check } from "../_libs/lucide-react.mjs";
import { c as packages, o as formatRand, r as activities, t as AppShell, u as quoteSelected } from "./shell-CrZ6Y0oo.mjs";
import { i as PrimaryButton } from "./bits-BgzWzA0I.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/fees-DOyU_VPr.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function FeesPage() {
	const navigate = useNavigate();
	const [selected, setSelected] = (0, import_react.useState)([]);
	const quote = (0, import_react.useMemo)(() => quoteSelected(selected), [selected]);
	function toggle(id) {
		setSelected((current) => current.includes(id) ? current.filter((item) => item !== id) : [...current, id]);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-3xl font-bold text-ink",
			children: "Fee calculator"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted",
			children: "Select experiences to estimate your total."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
			className: "mt-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
				className: "text-xs font-bold tracking-wide text-muted",
				children: "PACKAGES"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-2 space-y-2",
				children: packages.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FeeRow, {
					name: item.name,
					price: formatRand(item.price),
					checked: selected.includes(item.id),
					onToggle: () => toggle(item.id)
				}, item.id))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
			className: "mt-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
				className: "text-xs font-bold tracking-wide text-muted",
				children: "ACTIVITIES"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-2 space-y-2",
				children: activities.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FeeRow, {
					name: item.name,
					price: formatRand(item.price),
					checked: selected.includes(item.id),
					onToggle: () => toggle(item.id)
				}, item.id))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-5 rounded-card bg-ink p-5 text-on-ink",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-bold tracking-widest text-sun",
					children: "ESTIMATED TOTAL"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 font-display text-4xl font-bold text-snow tabular-nums",
					children: formatRand(quote.total, 2)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "mt-4 space-y-1.5 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							label: "Subtotal",
							value: formatRand(quote.subtotal, 2)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							label: quote.items.length >= 2 ? "Discount (5%)" : "Discount",
							value: quote.discount ? `− ${formatRand(quote.discount, 2)}` : formatRand(0, 2)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							label: "VAT (15%)",
							value: formatRand(quote.vat, 2)
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-xs leading-relaxed text-on-ink",
					children: "Two or more experiences take 5% off the subtotal, then 15% VAT is added. Final quote confirmed at booking."
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
			className: "mt-5",
			type: "button",
			onClick: () => navigate({
				to: "/book",
				search: { experience: quote.items[0]?.id }
			}),
			children: "Continue to booking"
		})
	] });
}
function Row({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-between gap-3 text-on-ink",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "font-semibold tabular-nums",
			children: value
		})]
	});
}
function FeeRow({ name, price, checked, onToggle }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		role: "checkbox",
		"aria-checked": checked,
		onClick: onToggle,
		className: `flex min-h-14 w-full items-center gap-3 rounded-card border bg-card px-3 text-left ${checked ? "border-forest" : "border-line"}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: `grid size-5 shrink-0 place-items-center rounded border-2 border-forest ${checked ? "bg-forest text-snow" : "bg-card"}`,
				"aria-hidden": "true",
				children: checked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
					className: "size-3.5",
					strokeWidth: 3
				}) : null
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "min-w-0 flex-1 text-sm font-semibold text-ink",
				children: name
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm font-extrabold text-forest tabular-nums",
				children: price
			})
		]
	}) });
}
//#endregion
export { FeesPage as component };
