import { C as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as useAdventure, l as prettyDate, o as formatRand, t as AppShell } from "./shell-CrZ6Y0oo.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/confirmation-BYCNWuXF.js
var import_jsx_runtime = require_jsx_runtime();
function ConfirmationPage() {
	const hydrated = useAdventure((state) => state.hydrated);
	const booking = useAdventure((state) => state.bookings[0]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-card border border-line bg-card px-5 py-8 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto grid size-20 place-items-center rounded-full bg-mist text-4xl font-bold text-forest",
				children: "✓"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-4 font-display text-3xl font-bold text-ink",
				children: "You’re all set!"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: "Your booking request has been received."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("hr", { className: "my-5 border-line" }),
			hydrated && booking ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-left",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-bold tracking-widest text-muted",
						children: "REFERENCE"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-display text-2xl font-bold text-ink",
						children: booking.reference
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-sm font-semibold text-ink",
						children: booking.experienceName
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted",
						children: [
							prettyDate(booking.date),
							" · ",
							booking.guests,
							" ",
							booking.guests === 1 ? "guest" : "guests"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm font-bold text-forest tabular-nums",
						children: [formatRand(booking.total, 2), " estimated"]
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-left",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-bold tracking-widest text-muted",
					children: "REFERENCE"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: hydrated ? "No request yet. Choose a package or activity to plan a day out." : "Loading your request…"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-6 text-left text-sm font-extrabold text-forest",
				children: "Next steps"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-left text-sm leading-relaxed text-muted",
				children: "Our team will contact you to confirm availability and final details."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/home",
				className: "mt-6 inline-flex h-12 w-full items-center justify-center rounded-control bg-ember text-sm font-semibold text-snow",
				children: "Back to Home"
			})
		]
	}) });
}
//#endregion
export { ConfirmationPage as component };
