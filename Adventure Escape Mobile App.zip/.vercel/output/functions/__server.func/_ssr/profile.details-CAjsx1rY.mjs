import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Y as require_react, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as useAdventure, t as AppShell } from "./shell-CrZ6Y0oo.mjs";
import { i as PrimaryButton, n as FieldLabel, t as FieldError } from "./bits-BgzWzA0I.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/profile.details-CAjsx1rY.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var inputClass = "h-12 w-full rounded-control border border-line bg-card px-3.5 text-base text-ink outline-none placeholder:text-faint focus:border-forest focus:ring-2 focus:ring-forest/25";
function DetailsPage() {
	const profile = useAdventure((state) => state.profile);
	const setProfile = useAdventure((state) => state.setProfile);
	const [name, setName] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	const [saved, setSaved] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!profile) return;
		setName(profile.name);
		setEmail(profile.email);
		setPhone(profile.phone);
	}, [profile]);
	function submit(event) {
		event.preventDefault();
		if (name.trim().length < 2) {
			setError("Enter your full name.");
			return;
		}
		if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
			setError("Enter a valid email address.");
			return;
		}
		setProfile({
			name: name.trim(),
			email: email.trim(),
			phone: phone.trim()
		});
		setError("");
		setSaved(true);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/profile",
			className: "text-sm font-semibold text-forest",
			children: "Back to profile"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-3 font-display text-3xl font-bold text-ink",
			children: "Personal details"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted",
			children: "These details stay on this device and fill in new bookings."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "mt-5 space-y-4",
			onSubmit: submit,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
					htmlFor: "detail-name",
					children: "Full name"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					id: "detail-name",
					className: inputClass,
					value: name,
					onChange: (event) => setName(event.target.value)
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
					htmlFor: "detail-email",
					children: "Email"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					id: "detail-email",
					type: "email",
					className: inputClass,
					value: email,
					onChange: (event) => setEmail(event.target.value)
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
					htmlFor: "detail-phone",
					children: "Phone"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					id: "detail-phone",
					type: "tel",
					className: inputClass,
					placeholder: "+27",
					value: phone,
					onChange: (event) => setPhone(event.target.value)
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { children: error }),
				saved ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold text-forest",
					children: "Details saved."
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
					type: "submit",
					children: "Save details"
				})
			]
		})
	] });
}
//#endregion
export { DetailsPage as component };
