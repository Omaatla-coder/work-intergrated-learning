import { C as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as formatRand, r as activities, t as AppShell } from "./shell-CrZ6Y0oo.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/home-Ci-eaHne.js
var import_jsx_runtime = require_jsx_runtime();
function HomePage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "relative overflow-hidden rounded-card bg-mist",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: "/photos/cape.jpg",
				alt: "Western Cape mountains in late light",
				className: "h-48 w-full object-cover"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "absolute inset-x-0 bottom-0 bg-gradient-to-t from-ink/80 to-transparent px-3 py-3 text-center text-xs font-bold tracking-widest text-snow",
				children: "ADVENTURE STARTS HERE"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
			className: "mt-6 font-display text-3xl font-bold leading-tight text-ink",
			children: [
				"Discover Your Next",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
				"Adventure"
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-muted",
			children: "Explore the beauty of the Western Cape."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-3 flex gap-4 text-sm font-semibold text-forest",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/about",
				className: "underline decoration-forest/40 underline-offset-4",
				children: "Our story"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/location",
				className: "underline decoration-forest/40 underline-offset-4",
				children: "Find us"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/packages",
			className: "mt-5 inline-flex h-12 w-full items-center justify-center rounded-control bg-ember text-sm font-semibold text-snow transition hover:bg-ember-deep active:scale-95",
			children: "Explore Packages"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mt-8 font-display text-xl font-bold text-ink",
			children: "Popular experiences"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-3 grid grid-cols-3 gap-2.5",
			children: activities.map((activity) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/book",
				search: { experience: activity.id },
				className: "block rounded-card border border-line bg-card p-1.5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: activity.image,
						alt: "",
						className: "h-16 w-full rounded-lg object-cover"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 truncate px-0.5 text-xs font-bold text-ink",
						children: activity.shortName
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "px-0.5 pb-1 text-sm font-extrabold text-forest tabular-nums",
						children: formatRand(activity.price)
					})
				]
			}) }, activity.id))
		})
	] });
}
//#endregion
export { HomePage as component };
