import { C as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { u as Heart } from "../_libs/lucide-react.mjs";
import { f as useAdventure } from "./shell-CrZ6Y0oo.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/bits-BgzWzA0I.js
var import_jsx_runtime = require_jsx_runtime();
var primaryClass = "inline-flex h-12 w-full items-center justify-center rounded-control bg-ember px-4 text-sm font-semibold text-snow transition hover:bg-ember-deep active:scale-95 disabled:cursor-not-allowed disabled:opacity-50";
var inkClass = "inline-flex h-12 w-full items-center justify-center rounded-control bg-ink px-4 text-sm font-semibold text-snow transition hover:bg-ink-soft active:scale-95";
function PrimaryButton(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		...props,
		className: `${primaryClass} ${props.className ?? ""}`
	});
}
function InkButton(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		...props,
		className: `${inkClass} ${props.className ?? ""}`
	});
}
function FieldLabel({ htmlFor, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
		htmlFor,
		className: "mb-1.5 block text-xs font-bold text-ink",
		children
	});
}
function FieldError({ children }) {
	if (!children) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mt-1.5 text-xs font-semibold text-ember",
		children
	});
}
function SaveButton({ id }) {
	const hydrated = useAdventure((state) => state.hydrated);
	const saved = useAdventure((state) => state.saved.includes(id));
	const toggleSaved = useAdventure((state) => state.toggleSaved);
	const on = hydrated && saved;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-pressed": on,
		"aria-label": on ? "Remove from saved adventures" : "Save this adventure",
		onClick: () => toggleSaved(id),
		className: "grid size-11 place-items-center rounded-full bg-card text-forest shadow-sm",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, {
			className: `size-5 ${on ? "fill-forest" : ""}`,
			"aria-hidden": "true"
		})
	});
}
//#endregion
export { SaveButton as a, PrimaryButton as i, FieldLabel as n, InkButton as r, FieldError as t };
