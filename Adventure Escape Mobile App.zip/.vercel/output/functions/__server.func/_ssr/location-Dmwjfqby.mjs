import { C as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as MapPin } from "../_libs/lucide-react.mjs";
import { t as AppShell } from "./shell-CrZ6Y0oo.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/location-Dmwjfqby.js
var import_jsx_runtime = require_jsx_runtime();
function LocationPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-3xl font-bold text-ink",
			children: "Find your adventure"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted",
			children: "Western Cape, South Africa"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative mt-5 overflow-hidden rounded-card border border-line bg-mist",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/photos/aerial.jpg",
					alt: "Aerial view of the Cape Peninsula, where adventures are based",
					className: "h-72 w-full object-cover"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute left-1/2 top-1/2 grid -translate-x-1/2 -translate-y-1/2 place-items-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid size-12 place-items-center rounded-full border-4 border-snow bg-ember text-snow shadow-lg",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, {
							className: "size-5",
							"aria-hidden": "true"
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "absolute bottom-3 left-3 rounded-full bg-ink/80 px-3 py-1 text-xs font-semibold text-snow",
					children: "Cape Peninsula"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mt-6 font-display text-xl font-bold text-ink",
			children: "Plan your route"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm leading-relaxed text-muted",
			children: "Exact meeting points are shared after your booking is confirmed."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/contact",
			className: "mt-6 inline-flex h-12 w-full items-center justify-center rounded-control bg-ember text-sm font-semibold text-snow transition hover:bg-ember-deep active:scale-95",
			children: "Contact our team"
		})
	] });
}
//#endregion
export { LocationPage as component };
