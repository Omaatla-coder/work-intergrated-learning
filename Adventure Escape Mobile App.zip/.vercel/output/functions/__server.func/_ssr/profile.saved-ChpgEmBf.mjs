import { C as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as findExperience, f as useAdventure, o as formatRand, t as AppShell } from "./shell-CrZ6Y0oo.mjs";
import { a as SaveButton } from "./bits-BgzWzA0I.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/profile.saved-ChpgEmBf.js
var import_jsx_runtime = require_jsx_runtime();
function SavedPage() {
	const hydrated = useAdventure((state) => state.hydrated);
	const items = useAdventure((state) => state.saved).map((id) => findExperience(id)).filter((item) => item !== void 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/profile",
			className: "text-sm font-semibold text-forest",
			children: "Back to profile"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-3 font-display text-3xl font-bold text-ink",
			children: "Saved adventures"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted",
			children: "Keep favourites in one place."
		}),
		!hydrated ? null : items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 rounded-card border border-line bg-card p-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Nothing saved yet. Tap the heart on a package or activity."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/activities",
				className: "mt-3 inline-flex text-sm font-semibold text-forest",
				children: "See activities"
			})]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-5 space-y-3",
			children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex gap-3 rounded-card border border-line bg-card p-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: item.image,
						alt: "",
						className: "h-20 w-20 rounded-card object-cover"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1 py-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-base font-bold text-ink",
								children: item.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm font-extrabold text-forest tabular-nums",
								children: [formatRand(item.price), item.perPerson ? " pp" : ""]
							}),
							item.kind === "package" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/packages/$id",
								params: { id: item.id },
								className: "mt-1 inline-flex text-sm font-semibold text-forest",
								children: "View details"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/book",
								search: { experience: item.id },
								className: "mt-1 inline-flex text-sm font-semibold text-forest",
								children: "Book activity"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SaveButton, { id: item.id })
				]
			}, item.id))
		})
	] });
}
//#endregion
export { SavedPage as component };
