import { C as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as packages, o as formatRand, t as AppShell } from "./shell-CrZ6Y0oo.mjs";
import { a as SaveButton } from "./bits-BgzWzA0I.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/packages-BYM8vmDX.js
var import_jsx_runtime = require_jsx_runtime();
function PackagesPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-3xl font-bold text-ink",
			children: "Choose your adventure"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted",
			children: "Simple packages. Big memories."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-5 space-y-3",
			children: packages.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex gap-3 rounded-card border border-line bg-card p-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative h-28 w-28 shrink-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: item.image,
						alt: "",
						className: "h-full w-full rounded-card object-cover"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "absolute inset-x-0 bottom-0 rounded-b-card bg-ink/70 px-1 py-1 text-center text-xs font-bold tracking-wide text-snow",
						children: item.badge.toUpperCase()
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-w-0 flex-1 flex-col py-1 pr-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-base font-bold leading-tight text-ink",
								children: item.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SaveButton, { id: item.id })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs text-muted",
							children: item.tagline
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-auto pt-2 text-lg font-extrabold text-forest tabular-nums",
							children: formatRand(item.price)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/packages/$id",
							params: { id: item.id },
							className: "mt-2 inline-flex h-11 items-center justify-center rounded-control bg-ember text-sm font-semibold text-snow",
							children: "View details"
						})
					]
				})]
			}, item.id))
		})
	] });
}
//#endregion
export { PackagesPage as component };
