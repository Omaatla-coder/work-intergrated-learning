//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CpVPCj6s.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/about",
			"/activities",
			"/book",
			"/confirmation",
			"/contact",
			"/fees",
			"/home",
			"/location",
			"/profile",
			"/packages/$id",
			"/packages/"
		],
		preloads: [
			"/assets/index-B1pXF5FX.js",
			"/assets/useSelector-BcTnCC3_.js",
			"/assets/preload-helper-D9EI388e.js",
			"/assets/createLucideIcon-DNx5nm_q.js",
			"/assets/root-DLTE-HSj.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-B1pXF5FX.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DWD-KN9T.js", "/assets/shell-DbGF5rBE.js"]
	},
	"/about": {
		filePath: "/workspace/src/routes/about.tsx",
		children: void 0,
		preloads: ["/assets/about-DjzlPNC0.js", "/assets/shell-DbGF5rBE.js"]
	},
	"/activities": {
		filePath: "/workspace/src/routes/activities.tsx",
		children: void 0,
		preloads: [
			"/assets/activities-C0yUFv5H.js",
			"/assets/shell-DbGF5rBE.js",
			"/assets/bits-B9nVqYaZ.js"
		]
	},
	"/book": {
		filePath: "/workspace/src/routes/book.tsx",
		children: void 0,
		preloads: [
			"/assets/book-RgYVVNW6.js",
			"/assets/useNavigate-DT9pUn6d.js",
			"/assets/shell-DbGF5rBE.js",
			"/assets/bits-B9nVqYaZ.js"
		]
	},
	"/confirmation": {
		filePath: "/workspace/src/routes/confirmation.tsx",
		children: void 0,
		preloads: ["/assets/confirmation-CFdCRRq-.js", "/assets/shell-DbGF5rBE.js"]
	},
	"/contact": {
		filePath: "/workspace/src/routes/contact.tsx",
		children: void 0,
		preloads: [
			"/assets/contact-h0XuXCrq.js",
			"/assets/shell-DbGF5rBE.js",
			"/assets/bits-B9nVqYaZ.js"
		]
	},
	"/fees": {
		filePath: "/workspace/src/routes/fees.tsx",
		children: void 0,
		preloads: [
			"/assets/fees--vrj-ap_.js",
			"/assets/useNavigate-DT9pUn6d.js",
			"/assets/shell-DbGF5rBE.js",
			"/assets/bits-B9nVqYaZ.js"
		]
	},
	"/home": {
		filePath: "/workspace/src/routes/home.tsx",
		children: void 0,
		preloads: ["/assets/home-BWEcuIMD.js", "/assets/shell-DbGF5rBE.js"]
	},
	"/location": {
		filePath: "/workspace/src/routes/location.tsx",
		children: void 0,
		preloads: ["/assets/location-5oHwWscB.js", "/assets/shell-DbGF5rBE.js"]
	},
	"/profile": {
		filePath: "/workspace/src/routes/profile.tsx",
		children: [
			"/profile/bookings",
			"/profile/details",
			"/profile/help",
			"/profile/saved",
			"/profile/"
		],
		preloads: ["/assets/profile-BLIb80QH.js"]
	},
	"/packages/$id": {
		filePath: "/workspace/src/routes/packages/$id.tsx",
		children: void 0,
		preloads: [
			"/assets/_id-Dhi0VKGJ.js",
			"/assets/shell-DbGF5rBE.js",
			"/assets/bits-B9nVqYaZ.js"
		]
	},
	"/profile/bookings": {
		filePath: "/workspace/src/routes/profile.bookings.tsx",
		children: void 0,
		preloads: ["/assets/profile.bookings-Dkf7RhVR.js", "/assets/shell-DbGF5rBE.js"]
	},
	"/profile/details": {
		filePath: "/workspace/src/routes/profile.details.tsx",
		children: void 0,
		preloads: [
			"/assets/profile.details-CViOJHfu.js",
			"/assets/shell-DbGF5rBE.js",
			"/assets/bits-B9nVqYaZ.js"
		]
	},
	"/profile/help": {
		filePath: "/workspace/src/routes/profile.help.tsx",
		children: void 0,
		preloads: ["/assets/profile.help-B-eApKUv.js", "/assets/shell-DbGF5rBE.js"]
	},
	"/profile/saved": {
		filePath: "/workspace/src/routes/profile.saved.tsx",
		children: void 0,
		preloads: [
			"/assets/profile.saved-BMJIaxeH.js",
			"/assets/shell-DbGF5rBE.js",
			"/assets/bits-B9nVqYaZ.js"
		]
	},
	"/packages/": {
		filePath: "/workspace/src/routes/packages/index.tsx",
		children: void 0,
		preloads: [
			"/assets/packages-lXtkrUuJ.js",
			"/assets/shell-DbGF5rBE.js",
			"/assets/bits-B9nVqYaZ.js"
		]
	},
	"/profile/": {
		filePath: "/workspace/src/routes/profile.index.tsx",
		children: void 0,
		preloads: [
			"/assets/profile.index-CdrIZszh.js",
			"/assets/shell-DbGF5rBE.js",
			"/assets/bits-B9nVqYaZ.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
